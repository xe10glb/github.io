<?php

// in order to help peoples who have problems
// to install pfc on a strange configurated server
// this script is very usefull
echo "<pre>";
print_r($_SERVER);
echo "</pre>";

?>