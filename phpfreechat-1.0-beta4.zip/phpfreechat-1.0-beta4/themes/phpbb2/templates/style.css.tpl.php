div#<?php echo $prefix; ?>chat {
  width: 84%;
}

div#<?php echo $prefix; ?>smileys {
  width: 15%;
  height: 25%;
}
div#<?php echo $prefix; ?>online {
  width: 15%;
  height: 72%;
}
