div#<?php echo $prefix; ?>chat {
  width: 89%;
}

div#<?php echo $prefix; ?>smileys {
  width: 10%;
  height: 15%;
}
div#<?php echo $prefix; ?>online {
  width: 10%;
  height: 82%;
}
