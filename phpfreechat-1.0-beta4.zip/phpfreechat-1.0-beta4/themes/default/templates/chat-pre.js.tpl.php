/**
 * Put here the JS code to execute just before the pfcClient object instance creation
 */