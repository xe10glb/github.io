/**
 * Put here the JS code to execute just after the pfcClient object instance creation
 */