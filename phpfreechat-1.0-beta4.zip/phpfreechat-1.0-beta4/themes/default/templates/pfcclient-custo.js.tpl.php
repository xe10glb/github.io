/**
 * Put here the pfcClient customizations
 * ex: you can override the updateNickList methode
 *     in order to display links on the nicknames (see demo34 for a concrete example)
 */