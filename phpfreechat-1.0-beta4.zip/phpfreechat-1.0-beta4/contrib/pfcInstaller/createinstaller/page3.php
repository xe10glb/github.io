<?php
$uses[] = 'appname';
?>
<div><h2>Applactation Name</h2></div>
<div>What is the name of your applactation?</div>
<div class="margin">
	<input type="text" style="width:30em;" name="appname" id="appname" value="<?php echo gpv('appname'); ?>" />
</div>