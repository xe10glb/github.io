<?php
$uses[] = 'rootpath';
?>
<div style="text-align:left;"><h1>Welcome to the Installer creater.</h1></div>
<div><h2>Root path</h2></div>
<div>Where is the script directory?</div>
<div class="margin">
	<input type="text" style="width:30em;" name="rootpath" id="rootpath" value="<?php echo gpv('rootpath'); ?>" />
</div>