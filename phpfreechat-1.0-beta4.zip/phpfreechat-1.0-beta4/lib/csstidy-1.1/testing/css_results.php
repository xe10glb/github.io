<?php
$xhtml_result = array ( 'standard' => array ( '.float-l' => array ( 'float' => 'left', ), '.form-suggest' => array ( 'height' => '200px', 'background' => '#DEE2D0', 'vertical-align' => 'top', ), '.hide' => array ( 'display' => 'none', ), '.form-input textarea' => array ( 'font-size' => '11px', 'width' => '350px', ), '.form-label' => array ( 'font-size' => '10px', 'font-weight' => '700', 'line-height' => '25px', 'padding-right' => '10px', 'text-align' => 'right', 'width' => '100px', 'color' => '#39738F', ), '.font-9' => array ( 'font-size' => '9px', ), '.form-topic' => array ( 'font-weight' => '700', ), '.form-error' => array ( 'color' => 'red', ), '.space-10' => array ( 'clear' => 'both', 'font-size' => '10px', 'height' => '10px', 'line-height' => '10px', ), '.suggest-success' => array ( 'color' => 'green', 'padding-left' => '10px', 'font-size' => '11px', 'font-weight' => '700', ), '.top' => array ( 'vertical-align' => 'top', ), 'table td' => array ( 'padding' => '3px', ), 'a:link,a:active,a:visited,a.postlink' => array ( 'color' => '#069', 'text-decoration' => 'none', ), 'a.but,a.but:hover,a.but:visited' => array ( 'color' => '#000', 'text-decoration' => 'none', ), 'a.topictitle:visited' => array ( 'color' => '#5493B4', ), 'body' => array ( 'color' => '#000', 'font' => '11px Verdana,Arial,Helvetica,sans-serif', 'overflow' => 'auto', 'margin' => '0 10px 10px', 'padding' => '0', ), 'font,th,td,p' => array ( 'font' => '12px Verdana,Arial,Helvetica,sans-serif', ), 'hr' => array ( 'border' => '0 solid #FFF', 'border-top-width' => '1px', 'height' => '0', ), 'img' => array ( 'border' => '0 solid', ), 'input' => array ( 'font' => '11px Verdana,Arial,Helvetica,sans-serif', ), 'input.button,input.liteoption,.fakebut' => array ( 'background' => '#FAFAFA', 'border' => '1px solid #000', 'font-size' => '11px', ), 'input.catbutton' => array ( 'background' => '#FAFAFA', 'border' => '1px solid #000', 'font-size' => '10px', ), 'input.mainoption' => array ( 'background' => '#FAFAFA', 'border' => '1px solid #000', 'font-size' => '11px', 'font-weight' => '700', ), 'input.post,textarea.post' => array ( 'background' => '#FFF', 'border' => '1px solid #000', 'font' => '11px Verdana,Arial,Helvetica,sans-serif', 'padding-bottom' => '2px', 'padding-left' => '2px', ), 'select' => array ( 'background' => '#FFF', 'font' => '11px Verdana,Arial,Helvetica,sans-serif', ), 'td' => array ( 'vertical-align' => 'middle', ), 'td.cat' => array ( 'background-color' => '#C2C6BA', 'font-weight' => '700', 'height' => '20px', 'letter-spacing' => '1px', 'text-indent' => '4px', ), 'td.genmed,.genmed' => array ( 'font-size' => '11px', ), 'td.rowpic' => array ( 'background' => '#C2C6BA', ), 'th' => array ( 'background-color' => '#FADD31', 'background-image' => 'url(images/cellpic3.gif)', 'background-repeat' => 'repeat-x', 'color' => '#68685E', 'font-size' => '11px', 'font-weight' => '700', 'line-height' => '16px', 'height' => '16px', 'padding-left' => '8px', 'padding-right' => '8px', 'text-align' => 'center', 'white-space' => 'nowrap', ), '.admin,a.admin,a.admin:visited' => array ( 'color' => '#FFA34F', ), '.bodyline' => array ( 'background' => '#FFF', 'border' => '1px solid #98AAB1', ), '.center' => array ( 'text-align' => 'center', ), '.code' => array ( 'background' => '#FAFAFA', 'border' => '1px solid #D1D7DC', 'color' => '#060', 'font' => '12px Courier,"Courier New",sans-serif', 'padding' => '5px', ), '.errorline' => array ( 'background' => '#E5E6E2', 'border' => '1px solid #8F8B8B', 'color' => '#D92A2A', ), '.explaintitle' => array ( 'color' => '#5C81B1', 'font-size' => '11px', 'font-weight' => '700', ), '.forumline' => array ( 'background' => '#FFF', ), '.h1-font' => array ( 'color' => '#069', 'display' => 'inline', 'font' => 'bold 13px Verdana, Arial, Helvetica, sans-serif', 'text-decoration' => 'none', 'margin' => '0', ), '.h2-font' => array ( 'display' => 'inline', 'font-family' => 'Verdana, Arial, Helvetica, sans-serif', 'font-size' => '11px', ), '.height1' => array ( 'height' => '1px', ), '.height22' => array ( 'height' => '22px', ), '.height25' => array ( 'height' => '25px', ), '.height28' => array ( 'height' => '28px', ), '.height30' => array ( 'height' => '30px', ), '.height40' => array ( 'height' => '40px', ), '.helpline' => array ( 'border' => '0 solid', 'font-size' => '10px', ), '.imgfolder' => array ( 'margin' => '1px 4px', ), '.imgspace' => array ( 'margin-left' => '1px', 'margin-right' => '2px', ), '.imgtopic,.imgicon' => array ( 'margin-left' => '3px', ), '.maintitle,h1,h2' => array ( 'color' => '#5C81B1', 'font' => 'bold 20px/120% "Trebuchet MS",Verdana,Arial,Helvetica,sans-serif', 'text-decoration' => 'none', ), '.maxwidth' => array ( 'width' => '100%', ), '.mod,a.mod,a.mod:visited' => array ( 'color' => '#060', ), '.nowrap' => array ( 'white-space' => 'nowrap', ), '.postbody' => array ( 'font-size' => '12px', 'line-height' => '125%', ), '.postdetails' => array ( 'color' => '#00396A', 'font-size' => '10px', ), '.quote' => array ( 'background' => '#F3F3EF', 'border' => '1px solid #C2C6BA', 'color' => '#069', 'font-size' => '11px', 'line-height' => '125%', ), '.right' => array ( 'text-align' => 'right', ), '.row1' => array ( 'background' => '#F0F0EB', ), '.row3' => array ( 'background' => '#DBDBD4', ), '.subtitle,h2' => array ( 'font' => 'bold 18px/180% "Trebuchet MS",Verdana,Arial,Helvetica,sans-serif', 'text-decoration' => 'none', ), '.topictitle' => array ( 'color' => '#000', 'font-size' => '11px', 'font-weight' => '700', ), '.image-hspace' => array ( 'margin-right' => '3px', ), '.clear' => array ( 'clear' => 'both', ), '.form-input input,.gensmall' => array ( 'font-size' => '10px', ), '.inline,form' => array ( 'display' => 'inline', ), 'a:hover,a.admin:hover,a.mod:hover,a.topictitle:hover' => array ( 'color' => '#DD6900', ), 'table,.left' => array ( 'text-align' => 'left', ), 'td.spacerow,.row2,.helpline' => array ( 'background' => '#E5E6E2', ), '.admin,.mod,.name,.nav' => array ( 'font-size' => '11px', 'font-weight' => '700', ), '.postbody a,.underline' => array ( 'text-decoration' => 'underline', ), ), );

$ala_result = array ( 'standard' => array ( '*' => array ( 'margin' => '0', 'padding' => '0', ), 'body' => array ( 'font' => '0.8125em Verdana, sans-serif', 'line-height' => '1', 'color' => '#333', 'background' => '#FFF', ), 'a' => array ( 'text-decoration' => 'none', ), 'a img' => array ( 'border' => 'none', ), 'a:link,a:visited' => array ( 'color' => '#555', 'border-bottom' => '1px solid #555', ), 'html body a:hover' => array ( 'color' => '#000', 'background-color' => '#F4F2E4', 'border-bottom' => '1px solid #9A8E51', ), 'h2' => array ( 'font' => '1.5em Georgia, "Times New Roman", serif', 'letter-spacing' => '1px', ), 'h3' => array ( 'font' => 'bold 1em Verdana, Arial, sans-serif', 'letter-spacing' => '2px', 'text-transform' => 'uppercase', ), 'h4' => array ( 'font' => 'bold 1.1em Georgia, "Times New Roman", serif', 'letter-spacing' => '1px', ), 'ul,ol' => array ( 'list-style' => 'none', ), 'blockquote,pre' => array ( 'padding' => '0.25em 40px', ), 'blockquote' => array ( 'font' => 'italic 1.05em Georgia, Times, serif', 'background' => 'url(/pix/quote_wh.gif) 10px 0.75em no-repeat', 'margin' => '0.25em 0', ), 'pre,code' => array ( 'font' => '1.05em Courier, monospace', ), 'pre' => array ( 'line-height' => '1.5em', ), 'pre strong' => array ( 'font-size' => '1em', 'font-weight' => '700', ), 'pre code' => array ( 'font-size' => '1em', 'line-height' => '1.5em', ), 'table' => array ( 'border-bottom' => '3px solid #B2B2B2', 'margin' => '0 0 2em', ), 'caption' => array ( 'font' => '1.5em Georgia, Times, serif', 'border' => '1px solid #B2B2B2', 'background' => '#EEE', 'border-width' => '1px 0 2px', 'padding' => '0.75em', ), 'th,td' => array ( 'border' => '1px solid #CCC', 'border-width' => '0 0 1px 1px', 'padding' => '0.5em 1em', ), 'th.first,td.first,tbody th' => array ( 'border-left' => 'none', ), 'thead th' => array ( 'text-transform' => 'uppercase', 'text-align' => 'left', ), 'tbody th' => array ( 'width' => '20%', ), 'tfoot' => array ( 'display' => 'none', ), '#masthead' => array ( 'position' => 'absolute', 'z-index' => '5', 'top' => '0', 'left' => '22px', ), '#masthead a' => array ( 'display' => 'block', 'background' => '#81817C', 'width' => '156px', ), '#masthead a:hover' => array ( 'background' => '#000', ), '#ish' => array ( 'position' => 'relative', 'z-index' => '10', 'border-top' => '1px solid #666', 'font' => 'bold 10px Arial, sans-serif', 'letter-spacing' => '1px', ), '#ish a:link,#ish a:visited' => array ( 'position' => 'absolute', 'top' => '-33px', 'left' => '150px', 'width' => '65px', 'padding-top' => '13px', 'text-align' => 'center', 'background' => 'url(/pix/ishbug.gif) top left no-repeat', 'color' => '#FFF', 'voice-family' => 'inherit', 'height' => '52px', ), '#ish a:hover' => array ( 'background-position' => 'bottom right', ), '#ish a em' => array ( 'display' => 'block', 'margin-top' => '-0.2em', 'font' => '2.33em Georgia, Times, serif', 'letter-spacing' => '0', ), '#navbar' => array ( 'height' => '2.4em', 'background' => '#FBFAF4', 'border-top' => '5px solid #333', 'font' => '18px Georgia, Times, serif', 'overflow' => 'hidden', 'min-width' => '750px', 'padding' => '0 0 0 215px', ), '#navbar li' => array ( 'float' => 'left', 'margin-right' => '5px', 'background' => 'url(/pix/diamond-black.gif) 100% 66% no-repeat', 'padding' => '0 23px 0 13px', ), '#navbar li a' => array ( 'display' => 'block', 'text-transform' => 'uppercase', 'color' => '#000', 'padding' => '0.75em 0 0.25em', ), '#navbar #feed' => array ( 'background' => 'none', ), '#navbar a:hover,.articles #navbar #articles a,.topics #navbar #topics a,.about #navbar #about a,.contact #navbar #contact a,.contribute #navbar #contribute a,.feed #navbar #feed a' => array ( 'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x', 'color' => '#555', ), '#main' => array ( 'float' => 'left', 'font-size' => '0.88em', 'background' => 'url(/pix/threecolbg.gif) 794px 0 repeat-y', 'voice-family' => 'inherit', 'width' => '750px', 'padding' => '1.5em 0 1.5em 210px', ), '#main p' => array ( 'text-align' => 'left', 'line-height' => '1.8em', 'margin' => '0 0 1em', ), '.column' => array ( 'float' => 'left', ), '#content' => array ( 'voice-family' => 'inherit', 'width' => '540px', 'padding' => '0 25px 0 20px', ), '#content .title' => array ( 'font' => '1.8em Georgia, Times, serif', 'margin-bottom' => '0.5em', ), '.title' => array ( 'text-transform' => 'none', 'letter-spacing' => '1px', ), '.title a:link,.title a:visited' => array ( 'color' => '#333', ), '.title a:hover' => array ( 'color' => '#000', ), '.byline' => array ( 'font' => 'italic 1.1em Times, serif', 'letter-spacing' => '1px', 'margin' => '0 0 1.5em', ), '.byline a:link,.byline a:visited' => array ( 'font' => 'bold 0.85em Verdana, sans-serif', 'text-transform' => 'uppercase', 'letter-spacing' => '2px', 'margin-left' => '0.25em', ), '#secondary' => array ( 'width' => '215px', ), '#secondary .title' => array ( 'margin-bottom' => '0.25em', ), '#choice' => array ( 'border-top' => '1px solid #D9D9D9', 'padding' => '1.5em 20px', ), '#choice h3' => array ( 'color' => '#333', 'font' => '0.9em Verdana, sans-serif', 'text-transform' => 'uppercase', 'letter-spacing' => '0.33em', ), '#choice .info' => array ( 'font-style' => 'italic', 'font-size' => '0.9em', 'color' => '#666', ), '#sidebar' => array ( 'padding-left' => '15px', 'voice-family' => 'inherit', 'width' => '140px', ), '#sidebar h3' => array ( 'font' => '1.5em Georgia, Times, serif', 'letter-spacing' => '0', 'text-transform' => 'none', 'margin-bottom' => '0.25em', 'color' => '#333', ), '#search' => array ( 'width' => '80px', ), '#search,#submit' => array ( 'vertical-align' => 'bottom', ), '#sidebar div' => array ( 'border-bottom' => '1px dashed #B2B2B2', 'padding' => '10px 0.5em', ), '#sidebar div.first' => array ( 'padding-top' => '0', ), '#sidebar li' => array ( 'padding' => '0.5em 0', ), '#sidebar li a:link,#sidebar li a:visited' => array ( 'padding-left' => '12px', 'background' => 'url(/pix/diamond-gray.gif) 0 0.4em no-repeat', ), '#sidebar p' => array ( 'font-size' => '0.85em', 'margin-top' => '0.25em', ), '#lucre,#lucre p' => array ( 'margin' => '0.5em 0 0', ), '#lucre p' => array ( 'text-align' => 'center', ), '#lucre p.ads' => array ( 'text-align' => 'left', 'line-height' => '1.5', ), '#lucre p a:link,#lucre p a:visited' => array ( 'color' => '#666', ), '#lucre p a:hover' => array ( 'color' => '#000', 'border-bottom-width' => '1px', ), '#colophon p' => array ( 'text-transform' => 'uppercase', 'letter-spacing' => '0.25em', 'text-align' => 'right', 'width' => '121px', 'color' => '#666', 'margin' => '0 auto', ), '#colophon img' => array ( 'background' => '#333', ), '#colophon a:hover img' => array ( 'background' => '#555', ), '#footer' => array ( 'clear' => 'both', 'border' => '1px solid #666', 'margin-bottom' => '3em', 'font-size' => '0.85em', 'background' => '#FBFAF4 url(/pix/pixelstoprose.gif) 20px 50% no-repeat', 'border-width' => '1px 0', ), '#footer p' => array ( 'margin-left' => '200px', 'border-left' => '1px solid #666', 'background' => '#FFF', 'padding' => '1em 20px', ), '#footer .copyright' => array ( 'padding-left' => '25px', 'background' => 'url(/pix/diamond-gray.gif) 10px 50% no-repeat', ), '#search,input[type="text"],input[type="password"],textarea' => array ( 'background' => '#FBFAF4', 'border' => '2px solid', 'border-color' => '#999 #D9D9D9 #D9D9D9 #999', ), '#masthead a,#ish a,#navbar a,#banners a,a.button,#main h1 a,.title a:link,.title a:visited,.byline a:link,.byline a:visited,#sidebar #colophon,#topiclist a,#lucre a,#colophon a,#footer a:link,#footer a:visited' => array ( 'border-bottom-width' => '0', ), '#main h1 a:hover,.title a:hover,.byline a:hover,#footer a:hover' => array ( 'border-bottom-width' => '1px', ), '#content .ishinfo,.issn' => array ( 'font' => '0.9em Verdana, sans-serif', 'text-transform' => 'uppercase', 'letter-spacing' => '0.33em', ), '#content .ishinfo b,.issn b' => array ( 'font' => '1.2em Georgia, Times, serif', 'letter-spacing' => '1px', ), ), );

$ala_options_result =     array (
  'standard' => 
  array (
    '*' => 
    array (
      'margin' => '0',
      'padding' => '0',
    ),
    'body' => 
    array (
      'font' => '0.8125em Verdana, sans-serif',
      'line-height' => '1',
      'color' => '#333',
      'background' => '#FFF',
    ),
    'a' => 
    array (
      'text-decoration' => 'none',
    ),
    'a img' => 
    array (
      'border' => 'none',
    ),
    'a:link' => 
    array (
      'color' => '#555',
      'border-bottom' => '1px solid #555',
    ),
    'a:visited' => 
    array (
      'color' => '#555',
      'border-bottom' => '1px solid #555',
    ),
    'html body a:hover' => 
    array (
      'color' => '#000',
      'background-color' => '#F4F2E4',
      'border-bottom' => '1px solid #9A8E51',
    ),
    '#masthead a' => 
    array (
      'border-bottom-width' => '0',
      'display' => 'block',
      'background' => '#81817C',
      'width' => '156px',
    ),
    '#ish a' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#navbar a' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#banners a' => 
    array (
      'border-bottom-width' => '0',
    ),
    'a.button' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#main h1 a' => 
    array (
      'border-bottom-width' => '0',
    ),
    '.title a:link' => 
    array (
      'border-bottom-width' => '0',
      'color' => '#333',
    ),
    '.title a:visited' => 
    array (
      'border-bottom-width' => '0',
      'color' => '#333',
    ),
    '.byline a:link' => 
    array (
      'border-bottom-width' => '0',
      'font' => 'bold 0.85em Verdana, sans-serif',
      'text-transform' => 'uppercase',
      'letter-spacing' => '2px',
      'margin-left' => '0.25em',
    ),
    '.byline a:visited' => 
    array (
      'border-bottom-width' => '0',
      'font' => 'bold 0.85em Verdana, sans-serif',
      'text-transform' => 'uppercase',
      'letter-spacing' => '2px',
      'margin-left' => '0.25em',
    ),
    '#main h1 a:hover' => 
    array (
      'border-bottom-width' => '1px',
    ),
    '.title a:hover' => 
    array (
      'border-bottom-width' => '1px',
      'color' => '#000',
    ),
    '.byline a:hover' => 
    array (
      'border-bottom-width' => '1px',
    ),
    'h2' => 
    array (
      'font' => '1.5em Georgia, "Times New Roman", serif',
      'letter-spacing' => '1px',
    ),
    'h3' => 
    array (
      'font' => 'bold 1em Verdana, Arial, sans-serif',
      'letter-spacing' => '2px',
      'text-transform' => 'uppercase',
    ),
    'h4' => 
    array (
      'font' => 'bold 1.1em Georgia, "Times New Roman", serif',
      'letter-spacing' => '1px',
    ),
    'ul' => 
    array (
      'list-style' => 'none',
    ),
    'ol' => 
    array (
      'list-style' => 'none',
    ),
    'blockquote' => 
    array (
      'padding' => '0.25em 40px',
      'font' => 'italic 1.05em Georgia, Times, serif',
      'background' => 'url(/pix/quote_wh.gif) 10px 0.75em no-repeat',
      'margin' => '0.25em 0',
    ),
    'pre' => 
    array (
      'padding' => '0.25em 40px',
      'font' => '1.05em Courier, monospace',
      'line-height' => '1.5em',
    ),
    'code' => 
    array (
      'font' => '1.05em Courier, monospace',
    ),
    'pre strong' => 
    array (
      'font-size' => '1em',
      'font-weight' => '700',
    ),
    'pre code' => 
    array (
      'font-size' => '1em',
      'line-height' => '1.5em',
    ),
    'table' => 
    array (
      'border-bottom' => '3px solid #B2B2B2',
      'margin' => '0 0 2em',
    ),
    'caption' => 
    array (
      'padding' => '0.75em',
      'font' => '1.5em Georgia, Times, serif',
      'border' => '1px solid #B2B2B2',
      'border-width' => '1px 0 2px',
      'background' => '#EEE',
    ),
    'th' => 
    array (
      'padding' => '0.5em 1em',
      'border' => '1px solid #CCC',
      'border-width' => '0 0 1px 1px',
    ),
    'td' => 
    array (
      'padding' => '0.5em 1em',
      'border' => '1px solid #CCC',
      'border-width' => '0 0 1px 1px',
    ),
    'th.first' => 
    array (
      'border-left' => 'none',
    ),
    'td.first' => 
    array (
      'border-left' => 'none',
    ),
    'tbody th' => 
    array (
      'border-left' => 'none',
      'width' => '20%',
    ),
    'thead th' => 
    array (
      'text-transform' => 'uppercase',
      'text-align' => 'left',
    ),
    'tfoot' => 
    array (
      'display' => 'none',
    ),
    '#masthead' => 
    array (
      'position' => 'absolute',
      'z-index' => '5',
      'top' => '0',
      'left' => '22px',
    ),
    '#masthead a:hover' => 
    array (
      'background' => '#000',
    ),
    '#ish' => 
    array (
      'position' => 'relative',
      'z-index' => '10',
      'border-top' => '1px solid #666',
      'font' => 'bold 10px Arial, sans-serif',
      'letter-spacing' => '1px',
    ),
    '#ish a:link' => 
    array (
      'position' => 'absolute',
      'top' => '-33px',
      'left' => '150px',
      'width' => '65px',
      'padding-top' => '13px',
      'text-align' => 'center',
      'background' => 'url(/pix/ishbug.gif) top left no-repeat',
      'color' => '#FFF',
      'voice-family' => 'inherit',
      'height' => '52px',
    ),
    '#ish a:visited' => 
    array (
      'position' => 'absolute',
      'top' => '-33px',
      'left' => '150px',
      'width' => '65px',
      'padding-top' => '13px',
      'text-align' => 'center',
      'background' => 'url(/pix/ishbug.gif) top left no-repeat',
      'color' => '#FFF',
      'voice-family' => 'inherit',
      'height' => '52px',
    ),
    '#ish a:hover' => 
    array (
      'background-position' => 'bottom right',
    ),
    '#ish a em' => 
    array (
      'display' => 'block',
      'margin-top' => '-0.2em',
      'font' => '2.33em Georgia, Times, serif',
      'letter-spacing' => '0',
    ),
    '#content .ishinfo' => 
    array (
      'font' => '0.9em Verdana, sans-serif',
      'text-transform' => 'uppercase',
      'letter-spacing' => '0.33em',
    ),
    '#content .ishinfo b' => 
    array (
      'font' => '1.2em Georgia, Times, serif',
      'letter-spacing' => '1px',
    ),
    '#navbar' => 
    array (
      'height' => '2.4em',
      'padding' => '0 0 0 215px',
      'background' => '#FBFAF4',
      'border-top' => '5px solid #333',
      'font' => '18px Georgia, Times, serif',
      'overflow' => 'hidden',
      'min-width' => '750px',
    ),
    '#navbar li' => 
    array (
      'float' => 'left',
      'padding' => '0 23px 0 13px',
      'margin-right' => '5px',
      'background' => 'url(/pix/diamond-black.gif) 100% 66% no-repeat',
    ),
    '#navbar li a' => 
    array (
      'display' => 'block',
      'padding' => '0.75em 0 0.25em',
      'text-transform' => 'uppercase',
      'color' => '#000',
    ),
    '#navbar #feed' => 
    array (
      'background' => 'none',
    ),
    '#navbar a:hover' => 
    array (
      'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x',
      'color' => '#555',
    ),
    '.articles #navbar #articles a' => 
    array (
      'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x',
      'color' => '#555',
    ),
    '.topics #navbar #topics a' => 
    array (
      'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x',
      'color' => '#555',
    ),
    '.about #navbar #about a' => 
    array (
      'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x',
      'color' => '#555',
    ),
    '.contact #navbar #contact a' => 
    array (
      'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x',
      'color' => '#555',
    ),
    '.contribute #navbar #contribute a' => 
    array (
      'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x',
      'color' => '#555',
    ),
    '.feed #navbar #feed a' => 
    array (
      'background' => 'url(/pix/navbarlinkbg.gif) top left repeat-x',
      'color' => '#555',
    ),
    '#main' => 
    array (
      'float' => 'left',
      'font-size' => '0.88em',
      'padding' => '1.5em 0 1.5em 210px',
      'background' => 'url(/pix/threecolbg.gif) 794px 0 repeat-y',
      'voice-family' => 'inherit',
      'width' => '750px',
    ),
    '#main p' => 
    array (
      'text-align' => 'left',
      'line-height' => '1.8em',
      'margin' => '0 0 1em',
    ),
    '.column' => 
    array (
      'float' => 'left',
    ),
    '#content' => 
    array (
      'padding' => '0 25px 0 20px',
      'voice-family' => 'inherit',
      'width' => '540px',
    ),
    '#content .title' => 
    array (
      'font' => '1.8em Georgia, Times, serif',
      'margin-bottom' => '0.5em',
    ),
    '.title' => 
    array (
      'text-transform' => 'none',
      'letter-spacing' => '1px',
    ),
    '.byline' => 
    array (
      'font' => 'italic 1.1em Times, serif',
      'letter-spacing' => '1px',
      'margin' => '0 0 1.5em',
    ),
    '#secondary' => 
    array (
      'width' => '215px',
    ),
    '#secondary .title' => 
    array (
      'margin-bottom' => '0.25em',
    ),
    '#choice' => 
    array (
      'border-top' => '1px solid #D9D9D9',
      'padding' => '1.5em 20px',
    ),
    '#choice h3' => 
    array (
      'color' => '#333',
      'font' => '0.9em Verdana, sans-serif',
      'text-transform' => 'uppercase',
      'letter-spacing' => '0.33em',
    ),
    '#choice .info' => 
    array (
      'font-style' => 'italic',
      'font-size' => '0.9em',
      'color' => '#666',
    ),
    '#sidebar' => 
    array (
      'padding-left' => '15px',
      'voice-family' => 'inherit',
      'width' => '140px',
    ),
    '#sidebar h3' => 
    array (
      'font' => '1.5em Georgia, Times, serif',
      'letter-spacing' => '0',
      'text-transform' => 'none',
      'margin-bottom' => '0.25em',
      'color' => '#333',
    ),
    '#search' => 
    array (
      'width' => '80px',
      'vertical-align' => 'bottom',
      'background' => '#FBFAF4',
      'border' => '2px solid',
      'border-color' => '#999 #D9D9D9 #D9D9D9 #999',
    ),
    '#submit' => 
    array (
      'vertical-align' => 'bottom',
    ),
    '#sidebar div' => 
    array (
      'border-bottom' => '1px dashed #B2B2B2',
      'padding' => '10px 0.5em',
    ),
    '#sidebar div.first' => 
    array (
      'padding-top' => '0',
    ),
    '#sidebar li' => 
    array (
      'padding' => '0.5em 0',
    ),
    '#sidebar li a:link' => 
    array (
      'padding-left' => '12px',
      'background' => 'url(/pix/diamond-gray.gif) 0 0.4em no-repeat',
    ),
    '#sidebar li a:visited' => 
    array (
      'padding-left' => '12px',
      'background' => 'url(/pix/diamond-gray.gif) 0 0.4em no-repeat',
    ),
    '#sidebar p' => 
    array (
      'font-size' => '0.85em',
      'margin-top' => '0.25em',
    ),
    '#lucre' => 
    array (
      'margin' => '0.5em 0 0',
    ),
    '#lucre p' => 
    array (
      'margin' => '0.5em 0 0',
      'text-align' => 'center',
    ),
    '#lucre p.ads' => 
    array (
      'text-align' => 'left',
      'line-height' => '1.5',
    ),
    '#lucre p a:link' => 
    array (
      'color' => '#666',
    ),
    '#lucre p a:visited' => 
    array (
      'color' => '#666',
    ),
    '#lucre p a:hover' => 
    array (
      'color' => '#000',
      'border-bottom-width' => '1px',
    ),
    '#sidebar #colophon' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#colophon p' => 
    array (
      'text-transform' => 'uppercase',
      'letter-spacing' => '0.25em',
      'text-align' => 'right',
      'width' => '121px',
      'margin' => '0 auto',
      'color' => '#666',
    ),
    '#colophon img' => 
    array (
      'background' => '#333',
    ),
    '#colophon a:hover img' => 
    array (
      'background' => '#555',
    ),
    '#topiclist a' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#lucre a' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#colophon a' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#footer' => 
    array (
      'clear' => 'both',
      'border' => '1px solid #666',
      'border-width' => '1px 0',
      'margin-bottom' => '3em',
      'font-size' => '0.85em',
      'background' => '#FBFAF4 url(/pix/pixelstoprose.gif) 20px 50% no-repeat',
    ),
    '#footer p' => 
    array (
      'margin-left' => '200px',
      'padding' => '1em 20px',
      'border-left' => '1px solid #666',
      'background' => '#FFF',
    ),
    '#footer a:link' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#footer a:visited' => 
    array (
      'border-bottom-width' => '0',
    ),
    '#footer a:hover' => 
    array (
      'border-bottom-width' => '1px',
    ),
    '.issn' => 
    array (
      'font' => '0.9em Verdana, sans-serif',
      'text-transform' => 'uppercase',
      'letter-spacing' => '0.33em',
    ),
    '.issn b' => 
    array (
      'font' => '1.2em Georgia, Times, serif',
      'letter-spacing' => '1px',
    ),
    '#footer .copyright' => 
    array (
      'padding-left' => '25px',
      'background' => 'url(/pix/diamond-gray.gif) 10px 50% no-repeat',
    ),
    'input[type="text"]' => 
    array (
      'background' => '#FBFAF4',
      'border' => '2px solid',
      'border-color' => '#999 #D9D9D9 #D9D9D9 #999',
    ),
    'input[type="password"]' => 
    array (
      'background' => '#FBFAF4',
      'border' => '2px solid',
      'border-color' => '#999 #D9D9D9 #D9D9D9 #999',
    ),
    'textarea' => 
    array (
      'background' => '#FBFAF4',
      'border' => '2px solid',
      'border-color' => '#999 #D9D9D9 #D9D9D9 #999',
    ),
  ),
);

$ala_options_comments = array ( 'standardtable' => ' handle legacy articles until markup gets a scrubbing ', 'standard#main' => ' IE5.x/Win hacks ', );

$ala_html = '<span class="selector">*</span> <span class="format">{</span>
<span class="property">margin:</span><span class="value">0</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">body</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">0.8125em Verdana, sans-serif</span><span class="format">;</span>
<span class="property">line-height:</span><span class="value">1</span><span class="format">;</span>
<span class="property">color:</span><span class="value">#333</span><span class="format">;</span>
<span class="property">background:</span><span class="value">#FFF</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">a</span> <span class="format">{</span>
<span class="property">text-decoration:</span><span class="value">none</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">a img</span> <span class="format">{</span>
<span class="property">border:</span><span class="value">none</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">a:link,a:visited</span> <span class="format">{</span>
<span class="property">color:</span><span class="value">#555</span><span class="format">;</span>
<span class="property">border-bottom:</span><span class="value">1px solid #555</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">html body a:hover</span> <span class="format">{</span>
<span class="property">color:</span><span class="value">#000</span><span class="format">;</span>
<span class="property">background-color:</span><span class="value">#F4F2E4</span><span class="format">;</span>
<span class="property">border-bottom:</span><span class="value">1px solid #9A8E51</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">h2</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">1.5em Georgia, &quot;Times New Roman&quot;, serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">1px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">h3</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">bold 1em Verdana, Arial, sans-serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">2px</span><span class="format">;</span>
<span class="property">text-transform:</span><span class="value">uppercase</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">h4</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">bold 1.1em Georgia, &quot;Times New Roman&quot;, serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">1px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">ul,ol</span> <span class="format">{</span>
<span class="property">list-style:</span><span class="value">none</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">blockquote,pre</span> <span class="format">{</span>
<span class="property">padding:</span><span class="value">0.25em 40px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">blockquote</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">italic 1.05em Georgia, Times, serif</span><span class="format">;</span>
<span class="property">background:</span><span class="value">url(/pix/quote_wh.gif) 10px 0.75em no-repeat</span><span class="format">;</span>
<span class="property">margin:</span><span class="value">0.25em 0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">pre,code</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">1.05em Courier, monospace</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">pre</span> <span class="format">{</span>
<span class="property">line-height:</span><span class="value">1.5em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">pre strong</span> <span class="format">{</span>
<span class="property">font-size:</span><span class="value">1em</span><span class="format">;</span>
<span class="property">font-weight:</span><span class="value">700</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">pre code</span> <span class="format">{</span>
<span class="property">font-size:</span><span class="value">1em</span><span class="format">;</span>
<span class="property">line-height:</span><span class="value">1.5em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">table</span> <span class="format">{</span>
<span class="property">border-bottom:</span><span class="value">3px solid #B2B2B2</span><span class="format">;</span>
<span class="property">margin:</span><span class="value">0 0 2em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">caption</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">1.5em Georgia, Times, serif</span><span class="format">;</span>
<span class="property">border:</span><span class="value">1px solid #B2B2B2</span><span class="format">;</span>
<span class="property">background:</span><span class="value">#EEE</span><span class="format">;</span>
<span class="property">border-width:</span><span class="value">1px 0 2px</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">0.75em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">th,td</span> <span class="format">{</span>
<span class="property">border:</span><span class="value">1px solid #CCC</span><span class="format">;</span>
<span class="property">border-width:</span><span class="value">0 0 1px 1px</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">0.5em 1em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">th.first,td.first,tbody th</span> <span class="format">{</span>
<span class="property">border-left:</span><span class="value">none</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">thead th</span> <span class="format">{</span>
<span class="property">text-transform:</span><span class="value">uppercase</span><span class="format">;</span>
<span class="property">text-align:</span><span class="value">left</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">tbody th</span> <span class="format">{</span>
<span class="property">width:</span><span class="value">20%</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">tfoot</span> <span class="format">{</span>
<span class="property">display:</span><span class="value">none</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#masthead</span> <span class="format">{</span>
<span class="property">position:</span><span class="value">absolute</span><span class="format">;</span>
<span class="property">z-index:</span><span class="value">5</span><span class="format">;</span>
<span class="property">top:</span><span class="value">0</span><span class="format">;</span>
<span class="property">left:</span><span class="value">22px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#masthead a</span> <span class="format">{</span>
<span class="property">display:</span><span class="value">block</span><span class="format">;</span>
<span class="property">background:</span><span class="value">#81817C</span><span class="format">;</span>
<span class="property">width:</span><span class="value">156px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#masthead a:hover</span> <span class="format">{</span>
<span class="property">background:</span><span class="value">#000</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#ish</span> <span class="format">{</span>
<span class="property">position:</span><span class="value">relative</span><span class="format">;</span>
<span class="property">z-index:</span><span class="value">10</span><span class="format">;</span>
<span class="property">border-top:</span><span class="value">1px solid #666</span><span class="format">;</span>
<span class="property">font:</span><span class="value">bold 10px Arial, sans-serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">1px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#ish a:link,#ish a:visited</span> <span class="format">{</span>
<span class="property">position:</span><span class="value">absolute</span><span class="format">;</span>
<span class="property">top:</span><span class="value">-33px</span><span class="format">;</span>
<span class="property">left:</span><span class="value">150px</span><span class="format">;</span>
<span class="property">width:</span><span class="value">65px</span><span class="format">;</span>
<span class="property">padding-top:</span><span class="value">13px</span><span class="format">;</span>
<span class="property">text-align:</span><span class="value">center</span><span class="format">;</span>
<span class="property">background:</span><span class="value">url(/pix/ishbug.gif) top left no-repeat</span><span class="format">;</span>
<span class="property">color:</span><span class="value">#FFF</span><span class="format">;</span>
<span class="property">voice-family:</span><span class="value">inherit</span><span class="format">;</span>
<span class="property">height:</span><span class="value">52px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#ish a:hover</span> <span class="format">{</span>
<span class="property">background-position:</span><span class="value">bottom right</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#ish a em</span> <span class="format">{</span>
<span class="property">display:</span><span class="value">block</span><span class="format">;</span>
<span class="property">margin-top:</span><span class="value">-0.2em</span><span class="format">;</span>
<span class="property">font:</span><span class="value">2.33em Georgia, Times, serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#navbar</span> <span class="format">{</span>
<span class="property">height:</span><span class="value">2.4em</span><span class="format">;</span>
<span class="property">background:</span><span class="value">#FBFAF4</span><span class="format">;</span>
<span class="property">border-top:</span><span class="value">5px solid #333</span><span class="format">;</span>
<span class="property">font:</span><span class="value">18px Georgia, Times, serif</span><span class="format">;</span>
<span class="property">overflow:</span><span class="value">hidden</span><span class="format">;</span>
<span class="property">min-width:</span><span class="value">750px</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">0 0 0 215px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#navbar li</span> <span class="format">{</span>
<span class="property">float:</span><span class="value">left</span><span class="format">;</span>
<span class="property">margin-right:</span><span class="value">5px</span><span class="format">;</span>
<span class="property">background:</span><span class="value">url(/pix/diamond-black.gif) 100% 66% no-repeat</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">0 23px 0 13px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#navbar li a</span> <span class="format">{</span>
<span class="property">display:</span><span class="value">block</span><span class="format">;</span>
<span class="property">text-transform:</span><span class="value">uppercase</span><span class="format">;</span>
<span class="property">color:</span><span class="value">#000</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">0.75em 0 0.25em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#navbar #feed</span> <span class="format">{</span>
<span class="property">background:</span><span class="value">none</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#navbar a:hover,.articles #navbar #articles a,.topics #navbar #topics a,.about #navbar #about a,.contact #navbar #contact a,.contribute #navbar #contribute a,.feed #navbar #feed a</span> <span class="format">{</span>
<span class="property">background:</span><span class="value">url(/pix/navbarlinkbg.gif) top left repeat-x</span><span class="format">;</span>
<span class="property">color:</span><span class="value">#555</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#main</span> <span class="format">{</span>
<span class="property">float:</span><span class="value">left</span><span class="format">;</span>
<span class="property">font-size:</span><span class="value">0.88em</span><span class="format">;</span>
<span class="property">background:</span><span class="value">url(/pix/threecolbg.gif) 794px 0 repeat-y</span><span class="format">;</span>
<span class="property">voice-family:</span><span class="value">inherit</span><span class="format">;</span>
<span class="property">width:</span><span class="value">750px</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">1.5em 0 1.5em 210px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#main p</span> <span class="format">{</span>
<span class="property">text-align:</span><span class="value">left</span><span class="format">;</span>
<span class="property">line-height:</span><span class="value">1.8em</span><span class="format">;</span>
<span class="property">margin:</span><span class="value">0 0 1em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">.column</span> <span class="format">{</span>
<span class="property">float:</span><span class="value">left</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#content</span> <span class="format">{</span>
<span class="property">voice-family:</span><span class="value">inherit</span><span class="format">;</span>
<span class="property">width:</span><span class="value">540px</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">0 25px 0 20px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#content .title</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">1.8em Georgia, Times, serif</span><span class="format">;</span>
<span class="property">margin-bottom:</span><span class="value">0.5em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">.title</span> <span class="format">{</span>
<span class="property">text-transform:</span><span class="value">none</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">1px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">.title a:link,.title a:visited</span> <span class="format">{</span>
<span class="property">color:</span><span class="value">#333</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">.title a:hover</span> <span class="format">{</span>
<span class="property">color:</span><span class="value">#000</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">.byline</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">italic 1.1em Times, serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">1px</span><span class="format">;</span>
<span class="property">margin:</span><span class="value">0 0 1.5em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">.byline a:link,.byline a:visited</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">bold 0.85em Verdana, sans-serif</span><span class="format">;</span>
<span class="property">text-transform:</span><span class="value">uppercase</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">2px</span><span class="format">;</span>
<span class="property">margin-left:</span><span class="value">0.25em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#secondary</span> <span class="format">{</span>
<span class="property">width:</span><span class="value">215px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#secondary .title</span> <span class="format">{</span>
<span class="property">margin-bottom:</span><span class="value">0.25em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#choice</span> <span class="format">{</span>
<span class="property">border-top:</span><span class="value">1px solid #D9D9D9</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">1.5em 20px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#choice h3</span> <span class="format">{</span>
<span class="property">color:</span><span class="value">#333</span><span class="format">;</span>
<span class="property">font:</span><span class="value">0.9em Verdana, sans-serif</span><span class="format">;</span>
<span class="property">text-transform:</span><span class="value">uppercase</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">0.33em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#choice .info</span> <span class="format">{</span>
<span class="property">font-style:</span><span class="value">italic</span><span class="format">;</span>
<span class="property">font-size:</span><span class="value">0.9em</span><span class="format">;</span>
<span class="property">color:</span><span class="value">#666</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#sidebar</span> <span class="format">{</span>
<span class="property">padding-left:</span><span class="value">15px</span><span class="format">;</span>
<span class="property">voice-family:</span><span class="value">inherit</span><span class="format">;</span>
<span class="property">width:</span><span class="value">140px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#sidebar h3</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">1.5em Georgia, Times, serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">0</span><span class="format">;</span>
<span class="property">text-transform:</span><span class="value">none</span><span class="format">;</span>
<span class="property">margin-bottom:</span><span class="value">0.25em</span><span class="format">;</span>
<span class="property">color:</span><span class="value">#333</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#search</span> <span class="format">{</span>
<span class="property">width:</span><span class="value">80px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#search,#submit</span> <span class="format">{</span>
<span class="property">vertical-align:</span><span class="value">bottom</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#sidebar div</span> <span class="format">{</span>
<span class="property">border-bottom:</span><span class="value">1px dashed #B2B2B2</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">10px 0.5em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#sidebar div.first</span> <span class="format">{</span>
<span class="property">padding-top:</span><span class="value">0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#sidebar li</span> <span class="format">{</span>
<span class="property">padding:</span><span class="value">0.5em 0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#sidebar li a:link,#sidebar li a:visited</span> <span class="format">{</span>
<span class="property">padding-left:</span><span class="value">12px</span><span class="format">;</span>
<span class="property">background:</span><span class="value">url(/pix/diamond-gray.gif) 0 0.4em no-repeat</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#sidebar p</span> <span class="format">{</span>
<span class="property">font-size:</span><span class="value">0.85em</span><span class="format">;</span>
<span class="property">margin-top:</span><span class="value">0.25em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#lucre,#lucre p</span> <span class="format">{</span>
<span class="property">margin:</span><span class="value">0.5em 0 0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#lucre p</span> <span class="format">{</span>
<span class="property">text-align:</span><span class="value">center</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#lucre p.ads</span> <span class="format">{</span>
<span class="property">text-align:</span><span class="value">left</span><span class="format">;</span>
<span class="property">line-height:</span><span class="value">1.5</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#lucre p a:link,#lucre p a:visited</span> <span class="format">{</span>
<span class="property">color:</span><span class="value">#666</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#lucre p a:hover</span> <span class="format">{</span>
<span class="property">color:</span><span class="value">#000</span><span class="format">;</span>
<span class="property">border-bottom-width:</span><span class="value">1px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#colophon p</span> <span class="format">{</span>
<span class="property">text-transform:</span><span class="value">uppercase</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">0.25em</span><span class="format">;</span>
<span class="property">text-align:</span><span class="value">right</span><span class="format">;</span>
<span class="property">width:</span><span class="value">121px</span><span class="format">;</span>
<span class="property">color:</span><span class="value">#666</span><span class="format">;</span>
<span class="property">margin:</span><span class="value">0 auto</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#colophon img</span> <span class="format">{</span>
<span class="property">background:</span><span class="value">#333</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#colophon a:hover img</span> <span class="format">{</span>
<span class="property">background:</span><span class="value">#555</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#footer</span> <span class="format">{</span>
<span class="property">clear:</span><span class="value">both</span><span class="format">;</span>
<span class="property">border:</span><span class="value">1px solid #666</span><span class="format">;</span>
<span class="property">margin-bottom:</span><span class="value">3em</span><span class="format">;</span>
<span class="property">font-size:</span><span class="value">0.85em</span><span class="format">;</span>
<span class="property">background:</span><span class="value">#FBFAF4 url(/pix/pixelstoprose.gif) 20px 50% no-repeat</span><span class="format">;</span>
<span class="property">border-width:</span><span class="value">1px 0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#footer p</span> <span class="format">{</span>
<span class="property">margin-left:</span><span class="value">200px</span><span class="format">;</span>
<span class="property">border-left:</span><span class="value">1px solid #666</span><span class="format">;</span>
<span class="property">background:</span><span class="value">#FFF</span><span class="format">;</span>
<span class="property">padding:</span><span class="value">1em 20px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#footer .copyright</span> <span class="format">{</span>
<span class="property">padding-left:</span><span class="value">25px</span><span class="format">;</span>
<span class="property">background:</span><span class="value">url(/pix/diamond-gray.gif) 10px 50% no-repeat</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#search,input[type=&quot;text&quot;],input[type=&quot;password&quot;],textarea</span> <span class="format">{</span>
<span class="property">background:</span><span class="value">#FBFAF4</span><span class="format">;</span>
<span class="property">border:</span><span class="value">2px solid</span><span class="format">;</span>
<span class="property">border-color:</span><span class="value">#999 #D9D9D9 #D9D9D9 #999</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#masthead a,#ish a,#navbar a,#banners a,a.button,#main h1 a,.title a:link,.title a:visited,.byline a:link,.byline a:visited,#sidebar #colophon,#topiclist a,#lucre a,#colophon a,#footer a:link,#footer a:visited</span> <span class="format">{</span>
<span class="property">border-bottom-width:</span><span class="value">0</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#main h1 a:hover,.title a:hover,.byline a:hover,#footer a:hover</span> <span class="format">{</span>
<span class="property">border-bottom-width:</span><span class="value">1px</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#content .ishinfo,.issn</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">0.9em Verdana, sans-serif</span><span class="format">;</span>
<span class="property">text-transform:</span><span class="value">uppercase</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">0.33em</span><span class="format"></span>
<span class="format">}</span>

<span class="selector">#content .ishinfo b,.issn b</span> <span class="format">{</span>
<span class="property">font:</span><span class="value">1.2em Georgia, Times, serif</span><span class="format">;</span>
<span class="property">letter-spacing:</span><span class="value">1px</span><span class="format"></span>
<span class="format">}</span>';
?>