<?php
// TOP //
include("index_html_top.php");
?>

<div class="content">
  <h2>Configuration</h2>

</div>

<?php
// BOTTOM
include("index_html_bottom.php");
?>