
<div class="footer">
      <div class="valid">
        <a href="http://validator.w3.org/check?uri=referer">
          <img alt="Valid XHTML 1.0!" src="style/valid-xhtml.png">
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
          <img alt="Valid CSS!" src="style/valid-css.png">
        </a>
      </div>
      <p>�2006 phpFreeChat</p>
    </div>
</body></html>