pfcClient.prototype.reloadColorList = function()
{
  this.colorlist = Array(  'green',
			   'blue',
			   'red',
			   '#567',
			   '#C33B3B'
			   );
}