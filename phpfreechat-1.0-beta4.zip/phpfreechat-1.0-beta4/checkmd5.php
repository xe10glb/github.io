<?php
$files_ok = array();
$files_ko = array();
if (md5(file_get_contents("./i18n/ar_LB/main.php")) == "a828a13cf965b6170c5167d7953ad381")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/ar_LB/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/ar_LB/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/sv_SE/main.php")) == "2628568928cfcad0881a82bc28ebb879")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/sv_SE/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/sv_SE/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/ja_JP/main.php")) == "0ae528d5c3d1ad393f0ca3bd7e3b61a8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/ja_JP/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/ja_JP/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/ba_BA/main.php")) == "25559947d4a1fe622156b76429349385")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/ba_BA/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/ba_BA/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/pt_PT/main.php")) == "fab746a1725c09fb73a73267969401ed")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/pt_PT/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/pt_PT/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/el_GR/main.php")) == "53a990d1b9abd1d6aa7b62344fefeba9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/el_GR/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/el_GR/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/tr_TR/main.php")) == "55414bbab4d378e1cc25533c140eb093")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/tr_TR/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/tr_TR/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/ua_UA/main.php")) == "6de4fffc01e5e269209032ec1b206aa5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/ua_UA/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/ua_UA/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/nb_NO/main.php")) == "6eda579a750f3aa1c72ba0985375718b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/nb_NO/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/nb_NO/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/zh_TW/main.php")) == "6a91f262441ad09c013e4f62a5c616ce")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/zh_TW/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/zh_TW/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/ru_RU/main.php")) == "4a45dbbaf0b993449e408d931e2dbf9e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/ru_RU/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/ru_RU/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/fr_FR/admin.php")) == "a2786b3d5c2d0bff0c2e561aedaff9d0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/fr_FR/admin.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/fr_FR/admin.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/fr_FR/main.php")) == "1b3aa42a7b7e9491ea1731f026f196f2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/fr_FR/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/fr_FR/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/es_ES/main.php")) == "13ee0f2deb2cabd1d3f0f8dd987b98af")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/es_ES/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/es_ES/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/bg_BG/main.php")) == "aeff28c9aac2a235507c36eb96d92a2e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/bg_BG/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/bg_BG/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/zh_CN/main.php")) == "d59efe6e848f6f0ab4a9a5837053cdfc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/zh_CN/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/zh_CN/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/nl_NL/main.php")) == "578ea6a2ea22b5badf624d65a6e2e128")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/nl_NL/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/nl_NL/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/de_DE-informal/main.php")) == "1922bb773dc0e2547a7bac55662f9b1c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/de_DE-informal/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/de_DE-informal/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/pt_BR/main.php")) == "3a0dc33d88d32d726247319b67c18b86")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/pt_BR/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/pt_BR/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/it_IT/main.php")) == "1565df2b8d6a04198836bb09f5f52997")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/it_IT/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/it_IT/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/id_ID/main.php")) == "8f61feffe00dd0ea6065c35a1d05886d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/id_ID/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/id_ID/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/hu_HU/main.php")) == "20da8d8406ee3ab33de035a8d6c17ab3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/hu_HU/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/hu_HU/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/en_US/admin.php")) == "08f5ebb48d33f239248443b28e9c4ffd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/en_US/admin.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/en_US/admin.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/en_US/main.php")) == "d2e3eda56f43502d79daedb192387f08")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/en_US/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/en_US/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/sr_CS/main.php")) == "edf186ad89616f73291b643a8e4c55a1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/sr_CS/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/sr_CS/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./i18n/de_DE-formal/main.php")) == "2be6fcfaef925d46ef7a3a2d7ca20208")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./i18n/de_DE-formal/main.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./i18n/de_DE-formal/main.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo5_customized_style_data/mytheme/images/newmsg.gif")) == "c1148ffba533cf181ca98b0d779330a1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo5_customized_style_data/mytheme/images/newmsg.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo5_customized_style_data/mytheme/images/newmsg.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo5_customized_style_data/mytheme/images/brick.jpg")) == "113df3c3b797b22ffd682c9fc2357c81")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo5_customized_style_data/mytheme/images/brick.jpg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo5_customized_style_data/mytheme/images/brick.jpg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo5_customized_style_data/mytheme/images/oldmsg.gif")) == "33eb60245c48c250ce1fbd3870e5ccd7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo5_customized_style_data/mytheme/images/oldmsg.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo5_customized_style_data/mytheme/images/oldmsg.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo5_customized_style_data/mytheme/templates/style.css.tpl.php")) == "e990d70f52c70a5c66b61589a2cb8a7a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo5_customized_style_data/mytheme/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo5_customized_style_data/mytheme/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo20_in_brazilian_portuguese.php")) == "0b0563bf3f53d763fbcc02424184274b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo20_in_brazilian_portuguese.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo20_in_brazilian_portuguese.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo3_server.php")) == "2556330e0b99d525fdfa7ce69e94b9d9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo3_server.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo3_server.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo18_phpbb2_smiley_theme.php")) == "b4fb01306d6a3954b6b7e968d954114a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo18_phpbb2_smiley_theme.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo18_phpbb2_smiley_theme.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo44_green_theme.php")) == "3cad325d812a3ea32173508316311e58")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo44_green_theme.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo44_green_theme.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo17_cerutti_smiley_theme.php")) == "78df449c4c1f388e42a2ee9c1f66a313")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo17_cerutti_smiley_theme.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo17_cerutti_smiley_theme.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo5_customized_style.php")) == "99adc42ee58606ee73caf6d1435bd588")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo5_customized_style.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo5_customized_style.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo27_customized_command.php")) == "7a2276711ca2998191c8a99d1a239d3c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo27_customized_command.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo27_customized_command.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo31_show_who_is_online-whoisonline.php")) == "d9e9dcddc5dde2e094a0a4530eaab453")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo31_show_who_is_online-whoisonline.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo31_show_who_is_online-whoisonline.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo22_in_serbian_croatian.php")) == "b4736c252506a54369b59de93db29d93")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo22_in_serbian_croatian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo22_in_serbian_croatian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo32_show_last_messages-showlastmsg.php")) == "3570fe97b3aa7afb5213d8f03e768c56")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo32_show_last_messages-showlastmsg.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo32_show_last_messages-showlastmsg.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo33_in_portuguese_from_portugal.php")) == "9cf3a12e78401ff8cdb2e579bf3acc87")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo33_in_portuguese_from_portugal.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo33_in_portuguese_from_portugal.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo9_with_a_utf8_encoded_nickname.php")) == "07221d005c98f773cfd122f8e85061dc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo9_with_a_utf8_encoded_nickname.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo9_with_a_utf8_encoded_nickname.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo34_add_a_link_on_nicknames.php")) == "5940bf66d784a25e1ae23c52e4314a4f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo34_add_a_link_on_nicknames.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo34_add_a_link_on_nicknames.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo42_in_chinese_from_taiwan.php")) == "65026054d6ec85b829dfa1e5e53da3fc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo42_in_chinese_from_taiwan.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo42_in_chinese_from_taiwan.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo4_simulate_slow_server.php")) == "b22ac828c19ad816f5058a57d75bf130")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo4_simulate_slow_server.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo4_simulate_slow_server.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo32_show_last_messages-config.php")) == "f8b7df1733d1a221a923182d9d8b189b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo32_show_last_messages-config.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo32_show_last_messages-config.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo31_show_who_is_online-config.php")) == "c5812a9d63a7ef60067b1af40ef0c484")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo31_show_who_is_online-config.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo31_show_who_is_online-config.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo45_in_bulgarian.php")) == "32a55ce261c8c1a875ff342773c68c04")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo45_in_bulgarian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo45_in_bulgarian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo8_with_a_iso-8859-1_encoded_page.php")) == "f0d8d291263737caf0cb05b46e7fdcad")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo8_with_a_iso-8859-1_encoded_page.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo8_with_a_iso-8859-1_encoded_page.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo26_in_swedish.php")) == "24792c6d0dbcaf7ef9c7e05281379ccb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo26_in_swedish.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo26_in_swedish.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo10_in_chinese.php")) == "97c2b6320a056d13d9e6fb1fa6bd1c4e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo10_in_chinese.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo10_in_chinese.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo12_phoenity_smiley_theme.php")) == "3b69df9192c945090d8907a6fed058b6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo12_phoenity_smiley_theme.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo12_phoenity_smiley_theme.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo14_in_german_formal_language.php")) == "5d6aa2388ed3067ff7a334072c0e81b3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo14_in_german_formal_language.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo14_in_german_formal_language.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo34_add_a_link_on_nicknames/mytheme/templates/pfcclient-custo.js.tpl.php")) == "bc24ce8d3f051dc5b24c7d70ac7bec66")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo34_add_a_link_on_nicknames/mytheme/templates/pfcclient-custo.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo34_add_a_link_on_nicknames/mytheme/templates/pfcclient-custo.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo37_in_dutch_from_netherlands.php")) == "95e1e9056572e7c4d262b4f89212a3b0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo37_in_dutch_from_netherlands.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo37_in_dutch_from_netherlands.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo38_in_norwegian_bokmal.php")) == "59f409c649e038584e5a45dd1b8f63da")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo38_in_norwegian_bokmal.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo38_in_norwegian_bokmal.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo21_with_hardcoded_urls.php")) == "fc97501a89ea75485e479c0b9de7ccdc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo21_with_hardcoded_urls.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo21_with_hardcoded_urls.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo27_dice.class.php")) == "f5bd9c0fd30644870729f42200ed4879")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo27_dice.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo27_dice.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo15_multiple_channel.php")) == "c14348dd333497662ffc31e1ff81f13f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo15_multiple_channel.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo15_multiple_channel.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo25_in_indonesian.php")) == "66a4c937ea83f49c7a06649c11b9933a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo25_in_indonesian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo25_in_indonesian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo29_in_russian.php")) == "922e7605db10b76d8118d8e8d82850a9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo29_in_russian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo29_in_russian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo19_in_japanese.php")) == "33608ee88215461c08256a95eeafa382")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo19_in_japanese.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo19_in_japanese.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo3_config.php")) == "cca41e79dbe615948cee14001ce0ebca")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo3_config.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo3_config.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo41_in_greek.php")) == "df025fdad32d51acda2ea6722818ee19")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo41_in_greek.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo41_in_greek.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo2_simple_with_params.php")) == "b24b2d86cf83ff302a2127548606cac2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo2_simple_with_params.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo2_simple_with_params.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo39_in_bosnian.php")) == "e4fc72a370c188c808f1c5fba542e45b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo39_in_bosnian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo39_in_bosnian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo28_blune_theme.php")) == "e4cdd263a2d60f5f304f6b7c8ce9ace2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo28_blune_theme.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo28_blune_theme.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/index.php")) == "0f8192924a31bc44f09d726c53ebf2ba")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/index.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/index.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo13_in_german_informal_language.php")) == "8084782a13d46c1e5fc64c0e118481b0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo13_in_german_informal_language.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo13_in_german_informal_language.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo24_in_spanish.php")) == "f32c4cddc636c506833ddc6f23b83662")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo24_in_spanish.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo24_in_spanish.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo3_client.php")) == "c4b0207bce9ff4562477f8bd382c7c94")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo3_client.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo3_client.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo35_shared_memory.php")) == "c0f421af360a0718d4d033cefacbfaa1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo35_shared_memory.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo35_shared_memory.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo43_change_the_nicknames_colors.php")) == "cf8f152e39397f845d667da847365bd1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo43_change_the_nicknames_colors.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo43_change_the_nicknames_colors.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo7_in_english.php")) == "febb7e285afc7a69c811cf67a5b6c172")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo7_in_english.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo7_in_english.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo16_in_arabic.php")) == "28975cdb10da2d84b5e18fddc312dc87")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo16_in_arabic.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo16_in_arabic.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo1_simple.php")) == "ca83447f05ec72a82dc798725ac2140f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo1_simple.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo1_simple.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo43_change_the_nicknames_colors/mytheme/templates/pfcclient-custo.js.tpl.php")) == "cccaafe8ab1630307383b287b85b9b50")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo43_change_the_nicknames_colors/mytheme/templates/pfcclient-custo.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo43_change_the_nicknames_colors/mytheme/templates/pfcclient-custo.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo32_show_last_messages-chat.php")) == "3959b155855660c9c93335e65e935f79")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo32_show_last_messages-chat.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo32_show_last_messages-chat.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo23_in_italian.php")) == "b2cc797efc25677609bf509359f1e787")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo23_in_italian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo23_in_italian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo46_in_hungarian.php")) == "ed43b80741a6d39c7ac6c9b352533297")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo46_in_hungarian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo46_in_hungarian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo31_show_who_is_online-chat.php")) == "aace64c266c4014bed7eadebe7c869be")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo31_show_who_is_online-chat.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo31_show_who_is_online-chat.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo28_mini_blune_theme.php")) == "fa4810abd5197671b593306efe2774cc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo28_mini_blune_theme.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo28_mini_blune_theme.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo36_in_ukrainian.php")) == "77fcd930dd0572a4a0e4b560d34dafef")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo36_in_ukrainian.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo36_in_ukrainian.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo6_in_french.php")) == "1c78d28a5ebff14f1c96d4d1aed48fea")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo6_in_french.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo6_in_french.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo11_famfamfam_smiley_theme.php")) == "48b380dd401839f531c643fbb9fa53c8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo11_famfamfam_smiley_theme.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo11_famfamfam_smiley_theme.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./demo/demo40_in_turkish.php")) == "ef29cfcf95c7e4f7b56b87e949042739")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./demo/demo40_in_turkish.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./demo/demo40_in_turkish.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/happy.png")) == "ba79b8655ff133ce8ca92ae60c73c1f9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/happy.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/happy.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/cry.png")) == "e1209e55027107d428eb608be5a45303")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/cry.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/cry.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/theme")) == "cef0e97e06b0e7655e7869754e489055")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/theme</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/theme (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/tongue.png")) == "0d8be3cfef845b5b7c082ff5952adc9d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/tongue.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/tongue.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/omg.png")) == "7e46b23ed7b42e04409de85b9dbab4b3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/omg.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/omg.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/confused.png")) == "0a8cb5ae4cf3ab97b4553874237360a9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/confused.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/confused.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/lol.png")) == "bd5321c4efe6532827371632a331aac9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/lol.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/lol.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/caca.png")) == "70d7e6aabce7bdd60f201eefe3525737")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/caca.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/caca.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/sad.png")) == "dc7e856a342a6179addfcf079f16112b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/sad.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/sad.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/wink.png")) == "da1a6609b507a3b63e66f3e3da683157")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/wink.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/wink.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/dizzy.png")) == "6c4fed5689adaedd6a27844316fc9bca")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/dizzy.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/dizzy.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/smile.png")) == "c80d66c3ad960b512cd1dbd96edebb89")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/smile.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/smile.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/smileys/neutral.png")) == "37b38d73fb55923816cb524328935170")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/smileys/neutral.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/smileys/neutral.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/info.php")) == "74a782006acc5d1f7d5035c8f2a2b4c3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/info.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/info.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/cerutti/templates/style.css.tpl.php")) == "55d641ee5956bc56a91e2611c6d0a29c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/cerutti/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/cerutti/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/surprised.gif")) == "9dd0bae8ba4f092dcb69fae6d30f3c9d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/surprised.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/surprised.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/author.txt")) == "debe661cf6cde044944b5df151299f37")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/author.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/author.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/angry.gif")) == "51e8ddd378707afe08960b445f12ec11")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/angry.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/angry.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/normal.gif")) == "2dc7fa75980fe39c6cecf4c5818dbd73")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/normal.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/normal.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/lol.gif")) == "ba84335aa5cbd179443e96bae8947f7e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/lol.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/lol.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/razz.gif")) == "95e00ee6fba980dc067733cd9d01b3dc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/razz.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/razz.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/alien.gif")) == "041346982a5ab7caf90ebaaa677cd39a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/alien.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/alien.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/redface.gif")) == "3a7a7500543b11a012caf1db52494ad9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/redface.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/redface.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/arrow.gif")) == "29b2a1340d0aa879ee05a2ee1ff87902")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/arrow.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/arrow.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/cool.gif")) == "8584627443f4ddadcf42fc1635da9c4a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/cool.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/cool.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/cry.gif")) == "36215fb000e42ce42ce0decf787f9c26")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/cry.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/cry.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/rolleyes.gif")) == "9df2cb8541fef0b3e4e3587de2112e6e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/rolleyes.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/rolleyes.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/theme")) == "9020b706831b00b0e3ea5610036262ec")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/theme</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/theme (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/mrgreen.gif")) == "c473e4af346804fa9424c8f0828da63a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/mrgreen.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/mrgreen.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/evil.gif")) == "dd431e18a98d8e9d54a345590ae32377")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/evil.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/evil.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/laugh.gif")) == "12ed99bbd1f005d032d8ccf72cd6f32f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/laugh.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/laugh.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/idea.gif")) == "59cb7ca1114595e01f7f86a4dbedbd8e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/idea.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/idea.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/eek.gif")) == "8f0ec25612278ebb8147d55ae5f20e8b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/eek.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/eek.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/confused.gif")) == "b6985c61fea3d04687d15bf411152496")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/confused.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/confused.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/question.gif")) == "6d4a76eacdb033da1a03ddf674244e9a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/question.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/question.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/sad.gif")) == "750285e6074e9ea7c1057e23bfa4d24f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/sad.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/sad.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/wink.gif")) == "c4faa92f831c3154ead2381d57c07279")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/wink.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/wink.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/exclam.gif")) == "eff97cbebe3ebaa8c7fb170b0e021ecc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/exclam.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/exclam.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/dizzy.gif")) == "6a6f73439034d275cd9d0f1ac7a69fe7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/dizzy.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/dizzy.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/smileys/smile.gif")) == "100c0286316a4d19b42f5ccd565d6064")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/smileys/smile.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/smileys/smile.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phoenity/templates/style.css.tpl.php")) == "87c1c84be222945c6e685eb837341b91")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phoenity/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phoenity/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/green/images/pv-active.gif")) == "e16d305795a4b70c200d160abaf2b9e8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/green/images/pv-active.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/green/images/pv-active.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/green/images/ch-active.gif")) == "3149768414696468fc05265847317051")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/green/images/ch-active.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/green/images/ch-active.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/green/images/shade.gif")) == "ab7a16562a524d5b013897a255e82a14")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/green/images/shade.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/green/images/shade.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/green/images/pv.gif")) == "a2aa2c317784441d98fe6fa4fb12b40a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/green/images/pv.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/green/images/pv.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/green/images/ch.gif")) == "81da3989457825bf584c5d1afdfa3106")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/green/images/ch.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/green/images/ch.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/green/info.php")) == "c1b928cf2e0a869020e268b9e66ed9f2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/green/info.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/green/info.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/green/templates/style.css.tpl.php")) == "301ff0fa5d4367743c860e79991761a0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/green/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/green/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/online-separator.gif")) == "f9749c9009f83f152466b70d1a664ed8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/online-separator.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/online-separator.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/smiley-on.gif")) == "1132c8d0e3cf018012a2d5e94102a093")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/smiley-on.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/smiley-on.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_000000.gif")) == "b989b506300825f5a502c75f8ececeea")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_000000.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_000000.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/user-me.gif")) == "bae709e25e4e306cdb790d81246b32ff")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/user-me.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/user-me.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/user.gif")) == "31c2cf86904066530e7ba440357dc14a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/user.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/user.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_D2D2D2.gif")) == "98629b8374c5774daada1b78ebf24a86")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_D2D2D2.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_D2D2D2.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_FFFFFF.gif")) == "a382caf884d274d443b7a7361d486ce8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_FFFFFF.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_FFFFFF.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/tab_remove.gif")) == "e0ff46455a64eebd74d3ddb276931f62")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/tab_remove.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/tab_remove.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/shade.gif")) == "35e0a0bcb1b3aa882b55588879ff4f24")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/shade.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/shade.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_800000.gif")) == "82bfc69b079c51624fbee4d5bdf271c5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_800000.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_800000.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_008000.gif")) == "4c6dad7b9434563855f639981838f354")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_008000.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_008000.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/oldmsg.gif")) == "93e0d9395ab50ac583ad2c10e4c22643")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/oldmsg.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/oldmsg.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_800080.gif")) == "0fd2917312e1b64d0156d210088e128a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_800080.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_800080.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_008080.gif")) == "fd5248442cf42b3b2c4d49dde4e8dffb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_008080.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_008080.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_FF5500.gif")) == "78c03c77f9b60f80acf1d1e61599ce32")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_FF5500.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_FF5500.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/ch-active.gif")) == "e023fc8fa81deb9a0cdfc0797537c7c0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/ch-active.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/ch-active.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_FFFF00.gif")) == "96ef248701f121dba0a360f19e75fcb4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_FFFF00.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_FFFF00.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_FF00FF.gif")) == "fabdb297713d7b96d340501e16e60b48")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_FF00FF.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_FF00FF.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_00FFFF.gif")) == "069a55bad3acaaff9fc07883b4b2baf2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_00FFFF.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_00FFFF.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/clock-on.gif")) == "82419902c9c960e416306c4c093a631f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/clock-on.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/clock-on.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/bt_mail.gif")) == "3b6fdd504b49ded3f083e708a4d2ee79")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/bt_mail.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/bt_mail.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/login.gif")) == "7c2360c224f6c804847426d4a33493c1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/login.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/login.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/logout.gif")) == "60baad356387d2dee4022fd68609ed53")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/logout.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/logout.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/bt_pre.gif")) == "31ceb5b0b42d4e3314f19277276a4c3b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/bt_pre.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/bt_pre.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/bt_ins.gif")) == "fe0b57d5e6a4767a6bfcf9ce7516e013")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/bt_ins.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/bt_ins.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/minimize.gif")) == "30ced0f66c151fe83939c164330b3e0b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/minimize.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/minimize.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/maximize.gif")) == "ecea5fc23d3be504d75f17b10dd0b47f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/maximize.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/maximize.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/pv.gif")) == "82b28b933cf1e0f346fc58677a6b4f47")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/pv.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/pv.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/bt_em.gif")) == "5fcc83a83cbd47d0b25f6a7c9c8e0b77")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/bt_em.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/bt_em.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color-off.gif")) == "9e68c930f76269856ea2ca5e27e9ac5d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color-off.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color-off.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_000055.gif")) == "fe49f363d25608872081a7b021f0a0c2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_000055.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_000055.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color-on.gif")) == "77ece611597ecebe1423a56b8d7e06bc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color-on.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color-on.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_FF0000.gif")) == "91ffaf4142d81805acbdd38aa0e8ec24")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_FF0000.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_FF0000.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_00FF00.gif")) == "93d1e656797cf09a78aa2eb9f2f48891")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_00FF00.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_00FF00.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/bt_del.gif")) == "61e764993e4b2ed02ad30d5a4ffdf8aa")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/bt_del.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/bt_del.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_0000FF.gif")) == "80cb5f6556c308a5c34a32fc076cfff1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_0000FF.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_0000FF.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/ch.gif")) == "d26576e90f11482bb377e7dd80ad1f39")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/ch.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/ch.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/online-off.gif")) == "50fcde982c8f1bd6264b06f0be68b596")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/online-off.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/online-off.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/online-on.gif")) == "19a703d8b7594a503df58d1c956e272a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/online-on.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/online-on.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/pv-active.gif")) == "b26f2d236abf2f12cd3b479c570ad831")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/pv-active.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/pv-active.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/bt_strong.gif")) == "91dd80715c53c8e26c49f3a7ff82d828")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/bt_strong.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/bt_strong.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/bt_color.gif")) == "265ba919d9eef537c7f8d92f859cceda")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/bt_color.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/bt_color.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/clock-off.gif")) == "254ec3d6b534c947cbd8549dcf20681f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/clock-off.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/clock-off.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/color_7F7F7F.gif")) == "b917d1bb11ad04045cc36c6353678bbb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/color_7F7F7F.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/color_7F7F7F.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/images/smiley-off.gif")) == "c243239edc2d5e9df9e34978c7dced4c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/images/smiley-off.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/images/smiley-off.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/info.php")) == "c1b928cf2e0a869020e268b9e66ed9f2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/info.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/info.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_cigarette.gif")) == "136b67c5f06c2ce2fca562b0ebd14ac0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_cigarette.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_cigarette.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_computer.gif")) == "681ab1613f1c16260af0551d6748e566")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_computer.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_computer.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_away.gif")) == "ba0f5bee90980daebc947f1b8f4a05b2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_away.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_away.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_tongue.gif")) == "aaa70458bf6cd69e70d5d0e36b6f22af")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_tongue.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_tongue.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_dontknow.gif")) == "79f66d387ef7be6e90d6514e4ad3c1d5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_dontknow.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_dontknow.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_plate.gif")) == "c605dae169de7175febf26c108b4442b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_plate.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_plate.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_car.gif")) == "1be632c228e3f7234f55f19c3357a7e5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_car.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_car.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sad.gif")) == "65de771d331642697b10f4078c04fc74")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sad.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sad.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_drink.gif")) == "f592cca6c2c5fa68b5dbdfc55fd9cd92")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_drink.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_drink.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_cat.gif")) == "debe5495ac32c1ec84249e075e64576c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_cat.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_cat.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_fingerscrossed.gif")) == "060ecdb116be2852a87396b707e6d93e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_fingerscrossed.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_fingerscrossed.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_thumbdown.gif")) == "0bdd0133c44b68410c8aafd97317d145")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_thumbdown.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_thumbdown.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_kiss.gif")) == "8155230f268dbc70200f9521bd97e077")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_kiss.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_kiss.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_dog.gif")) == "016da97e9b4807ee74ea2243c582f4ae")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_dog.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_dog.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_star.gif")) == "90eecfdf2c786fc4d9d6a30989f2039b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_star.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_star.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_deadflower.gif")) == "6c3f5436a58ec2354778d1e3287fc7f4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_deadflower.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_deadflower.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_angry.gif")) == "de7d8369a1bdc21e90b12ecaceb3be95")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_angry.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_angry.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_ooooh.gif")) == "229770690af97f704f306c37beb1c4ff")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_ooooh.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_ooooh.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_photo.gif")) == "1a69b2eb42989bd855101a96909663c8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_photo.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_photo.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_boy.gif")) == "4d4e94744010373fdd74b2fe88bc21b6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_boy.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_boy.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_hot.gif")) == "5016c1b9bffa889822ff9a25df0e8f04")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_hot.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_hot.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_stormy.gif")) == "5d18d4dd2ce4bd87f10e28c9fb41f873")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_stormy.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_stormy.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_flower.gif")) == "d4486b8b37e5e04e2af5edd56e87e4b2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_flower.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_flower.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_rainbow.gif")) == "a92a5f2a6255f0de1e2cb92e753e6cc9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_rainbow.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_rainbow.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_idea.gif")) == "90c7d0fd141ef81f0691b05af121d012")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_idea.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_idea.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_heart.gif")) == "b88cb76e3415cca92a1397d3f0759968")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_heart.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_heart.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_bowl.gif")) == "0cb273f38ed21dfef3ba6b3edc4edc4a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_bowl.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_bowl.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_umbrella.gif")) == "583547b8b39ca01ed3eeb213978744f8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_umbrella.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_umbrella.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sheep.gif")) == "c067d767a4ce62d653feb5a1b1317ef1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sheep.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sheep.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sun.gif")) == "e284ffdf854b6144619d16fb7b88cfd2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sun.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sun.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sleep.gif")) == "5de060131577d41faa7b9905fd48fdfd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sleep.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sleep.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_neutral.gif")) == "314b193857a72951f6e13757002e4135")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_neutral.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_neutral.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_weird.gif")) == "f6a1caf92eec504b6c97faa9ef229040")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_weird.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_weird.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_soccer.gif")) == "3c7dda7ffc32c2a9f16017d2fb7998fb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_soccer.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_soccer.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_turtle.gif")) == "f9fa8300b8d46806e1a91a7205a78fb3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_turtle.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_turtle.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_online.gif")) == "1db28f6ef55a6abd924d6bd956711ad1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_online.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_online.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_xbox.gif")) == "ee1b2f5691108851dca8c8ff44ea1302")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_xbox.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_xbox.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_cellphone.gif")) == "bfeba2b52116654f3b1ebd1d65d5e794")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_cellphone.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_cellphone.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_donttell.gif")) == "9e8b0728342d828f0b44032d95942c03")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_donttell.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_donttell.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_film.gif")) == "3b75f3cb6f6729db7fe4f13c0f850769")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_film.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_film.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_icon.gif")) == "531b3814aeedadb6ea298ab157d9bd74")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_icon.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_icon.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_highfive.gif")) == "b059e1ba589cbdeccf2bbeb27ad19553")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_highfive.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_highfive.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_cry.gif")) == "24a7e85607b77df2ca351b9070455614")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_cry.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_cry.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_plane.gif")) == "cb6454c37f97ebcd104d9f48f9580c77")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_plane.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_plane.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_party.gif")) == "312e8faf0d264ef3520c9873a8c01cdf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_party.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_party.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_laugh.gif")) == "fa4df10bc0f59f9cd7fb3d17d9666809")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_laugh.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_laugh.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_smiley.gif")) == "1ee7380f552a1e8aa2dd3d79d42a1fc8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_smiley.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_smiley.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_devil.gif")) == "f0c8e3e78f63bc6efb22cbc5c865a51d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_devil.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_devil.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_occ.gif")) == "07cbf6ea5cb737eece58ba23a9a4714e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_occ.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_occ.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_note.gif")) == "574a48a41eed6f7ba30e9dc1d0e5bcca")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_note.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_note.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_bat.gif")) == "68ebb31be298bcfaf416b230e8d4cc36")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_bat.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_bat.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_phone.gif")) == "93683094f4d09077a5f36b70fcc473e4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_phone.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_phone.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_lightning.gif")) == "ff6bd1245c5976c8a5f8d1cd96dfa8c3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_lightning.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_lightning.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_eyeroll.gif")) == "e34f303e2a6897a9039da2ff9d5deef9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_eyeroll.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_eyeroll.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/gnu.gif")) == "c017971d158684c9c8c90465d463aad2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/gnu.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/gnu.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_beer.gif")) == "3d87073da754666de1ae484520067e68")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_beer.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_beer.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_think.gif")) == "9b686d115a52031f69c9560d6329e2b2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_think.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_think.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_gift.gif")) == "bdc2b2e4a5c5705d397c8814322c6d71")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_gift.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_gift.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/tux1.gif")) == "7daca5cbc2ed09d38745ae4455ec69fa")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/tux1.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/tux1.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/tux2.gif")) == "a243f306eb4b248130e32a016fc8e8bf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/tux2.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/tux2.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_runback.gif")) == "0a12e8849b43091a7994e7cb444bc8bf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_runback.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_runback.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_handcuffs.gif")) == "af1b4a62da5932578b43f6c0e62e2d81")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_handcuffs.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_handcuffs.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_angel.gif")) == "761927ceda5306fb4f555558b2d4e77e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_angel.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_angel.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_clock.gif")) == "8c33386946ac0cdcd6b2d7f7e5c79eb3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_clock.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_clock.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_girl.gif")) == "8404882aadbae0e7c2e32efafd6dcc0f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_girl.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_girl.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sarcastic.gif")) == "b7ab1a6f9dcdcc3a0f420aa44aad1d44")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sarcastic.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sarcastic.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sleepy.gif")) == "92fa97a6e8ff890d6870c5fd10088102")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sleepy.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sleepy.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_cake.gif")) == "f97eb0ab0f6cd85b308c3d450453c184")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_cake.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_cake.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_run.gif")) == "082c8ce4c434c47408bdce9b1f4a6a21")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_run.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_run.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_brb.gif")) == "069e799ebe2059e10f9afec6cdc53c90")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_brb.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_brb.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_snail.gif")) == "f3b0a85f1b7025d9e1f763f94018ff19")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_snail.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_snail.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_question.gif")) == "7a4f023c40389bbef08113d92384af51")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_question.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_question.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_wink.gif")) == "bb48a7ad6bc3eb337dd477aa1e199b51")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_wink.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_wink.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_teeth.gif")) == "62355df280ea829874a3a2d0c2fd3e2c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_teeth.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_teeth.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_island.gif")) == "688852a51f9296c19002119ba1502296")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_island.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_island.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_coins.gif")) == "9accfd4cf71ec99ba33d3ed686dfeed4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_coins.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_coins.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_nerd.gif")) == "c536cd997d2f943643b6d1285712f4c8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_nerd.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_nerd.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/theme")) == "9416aa435b29822261452ba722280a54")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/theme</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/theme (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sunglasses.gif")) == "59933cc704a8ca4ad93db092ad20b02d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sunglasses.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sunglasses.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_thumbup.gif")) == "d78bf1b8d73a4dbfb8f183f392cad6bd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_thumbup.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_thumbup.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_secret.gif")) == "71c843a5c1d2fa6f5d3b2eb610733886")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_secret.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_secret.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_brheart.gif")) == "637327f448a391921608263b7f9690ab")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_brheart.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_brheart.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_coffee.gif")) == "8e2ede77d072f9557ee09bac03709bf5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_coffee.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_coffee.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_email.gif")) == "e797693d1a564930d4ae5eeb832d4c94")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_email.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_email.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_embarrassed.gif")) == "1167cab2b4f41b27d93ac38ea3fac5db")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_embarrassed.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_embarrassed.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_sick.gif")) == "6c4b3703caac139fb4e38cb7a6823063")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_sick.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_sick.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/smileys/msn_pizza.gif")) == "3eec29dabde7af45ad119d33dd621eec")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/smileys/msn_pizza.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/smileys/msn_pizza.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/chat-post.js.tpl.php")) == "dbfc53be92776e1160412e54453414bc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/chat-post.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/chat-post.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/chat-pre.js.tpl.php")) == "94bb4c3cdcbf0db6cb294e0b37a566b3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/chat-pre.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/chat-pre.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/pfcclient-custo.js.tpl.php")) == "cfcad9be2c852eccdcc970ffe821076a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/pfcclient-custo.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/pfcclient-custo.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/chat.html.tpl.php")) == "ae1cc96c59d8a845fe77a1cc84817052")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/chat.html.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/chat.html.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/pfcclient.js.tpl.php")) == "9de8a1d79fbd192e9a7989f9a06f8672")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/pfcclient.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/pfcclient.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/pfci18n.js.tpl.php")) == "e0e98b441450af85ef54656c90e28b4d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/pfci18n.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/pfci18n.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/style.css.tpl.php")) == "f56377c763d4de1afa1719657242459f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/pfcgui.js.tpl.php")) == "ebda9186a63d6313ca6d8e6b4d1ea126")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/pfcgui.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/pfcgui.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/default/templates/chat.js.tpl.php")) == "ccfaef80669e0ee27fcf8a5276a637d6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/default/templates/chat.js.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/default/templates/chat.js.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/blune/images/online-off.gif")) == "2a674af5e4c079ffddd29636c32d4567")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/blune/images/online-off.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/blune/images/online-off.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/blune/images/smiley-on.gif")) == "d179fcd72ac088d1581293768995408f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/blune/images/smiley-on.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/blune/images/smiley-on.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/blune/images/online-on.gif")) == "b0d3ad5555be67098ad4744fa287587b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/blune/images/online-on.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/blune/images/online-on.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/blune/images/shade.gif")) == "f698bb62d97653ffa67194f15ca6dc67")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/blune/images/shade.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/blune/images/shade.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/blune/images/smiley-off.gif")) == "842cbed27d0c58f5266fd78571ec892b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/blune/images/smiley-off.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/blune/images/smiley-off.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/blune/info.php")) == "7c8ae17657410ec3383415e51cde7346")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/blune/info.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/blune/info.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/blune/templates/style.css.tpl.php")) == "735e5407a351bdb2600ffba4c24e09e9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/blune/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/blune/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/weather_lightning.png")) == "ca78d1154a753e06194a8670fa299a37")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/weather_lightning.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/weather_lightning.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_grin.png")) == "4c19e86a778db63a174dd7fb1e8a4164")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_grin.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_grin.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_tongue.png")) == "7fea338dbfc722d226ff913ea1245e1e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_tongue.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_tongue.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_wink.png")) == "3ba35fa086dbafb1b0da8014e0a4711d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_wink.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_wink.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/exclamation.png")) == "4e2b0acd496cc8d0f353c4d9ce57802c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/exclamation.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/exclamation.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/arrow_left.png")) == "914b321a39c1435fa6e3962d8bf89b7e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/arrow_left.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/arrow_left.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_smile.png")) == "37cb4f4944543114b5136440e7070a9c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_smile.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_smile.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/weather_snow.png")) == "9e647a97c80209161015ca34c5b941bf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/weather_snow.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/weather_snow.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_evilgrin.png")) == "45ed2f2633f0bba35acf9356e2c8ad75")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_evilgrin.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_evilgrin.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/weather_clouds.png")) == "eeba08234f9c57e6d146c5e44a6c4258")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/weather_clouds.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/weather_clouds.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/weather_rain.png")) == "fdf0ced556de4b594211baa651293b73")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/weather_rain.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/weather_rain.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/lightbulb.png")) == "c745e96ea9e86605cc709237dfe6a758")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/lightbulb.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/lightbulb.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/theme")) == "13500eb6c7210e3a4cec00ccffc73e0e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/theme</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/theme (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_surprised.png")) == "fe047e823ba4352031ea98ed3d97c4b6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_surprised.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_surprised.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/weather_cloudy.png")) == "bc2a4cdc39afa7031ce2de5513b70f9f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/weather_cloudy.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/weather_cloudy.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_happy.png")) == "ac432cfe8edabb8102632e91b21a64ae")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_happy.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_happy.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_unhappy.png")) == "af3027e182db9337f3d9a87db3f0fb2f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_unhappy.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_unhappy.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/weather_sun.png")) == "1b43ee09bf14dcb3144127ef9e15d58f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/weather_sun.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/weather_sun.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/emoticon_waii.png")) == "ea4f0c97d6dd519c1c5da5e62c6eef7c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/emoticon_waii.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/emoticon_waii.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/smileys/arrow_right.png")) == "25185605795016e7a6b5fea7e9b59ef3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/smileys/arrow_right.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/smileys/arrow_right.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/famfamfam/templates/style.css.tpl.php")) == "87c1c84be222945c6e685eb837341b91")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/famfamfam/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/famfamfam/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_wink.gif")) == "f058206bb8ff732dbe8e7aa10d74c9cd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_wink.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_wink.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_eek.gif")) == "52e43743e38a67d5d28845a104ca8c7d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_eek.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_eek.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_sad.gif")) == "5a50535a06def9d01076772e5e9d235b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_sad.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_sad.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_question.gif")) == "0518596a4eb94c32a2b2ed898bdc3549")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_question.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_question.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_think.gif")) == "532437bda0de45a9802e46edb9297ecc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_think.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_think.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_doh.gif")) == "98c85ed88ddf132d1844764745f623b5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_doh.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_doh.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_silenced.gif")) == "f0d041ecd9aeec95dd41a517f31ce7b1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_silenced.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_silenced.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_twisted.gif")) == "c9c3d12da1e9da699e490b86d24eee85")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_twisted.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_twisted.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_whistle.gif")) == "8b1565b7109ab4510d2cd7edefebc463")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_whistle.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_whistle.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_lol.gif")) == "b76e7729d43c4a49182d020741285bef")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_lol.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_lol.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_boohoo.gif")) == "801e99c1fa246dc76beca2b0edf981bb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_boohoo.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_boohoo.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_angel.gif")) == "ab86302adb7a6e13d0750dd1740e5c81")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_angel.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_angel.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_rolleyes.gif")) == "19071b1af987946e96dcef6ce0611c6b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_rolleyes.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_rolleyes.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_cool.gif")) == "25c83ea511f206e88f214719dad9c88c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_cool.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_cool.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_liar.gif")) == "c20ec555384f78001f2a31ae30d08df1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_liar.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_liar.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_confused.gif")) == "4affed1b55e5f73c9f0675ae7d0ad823")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_confused.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_confused.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_evil.gif")) == "178255bb3fe2c3aa790c1f8ec8738504")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_evil.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_evil.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_shhh.gif")) == "ee53d3e76c849a14bada50465c45619d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_shhh.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_shhh.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_wall.gif")) == "6cbafdf6a297dd1005981d0d3a71633e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_wall.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_wall.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_surprised.gif")) == "ae735b5dd659dc4b3b0f249ce59bef79")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_surprised.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_surprised.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_smile.gif")) == "9ee646ffab71107d1a11407be52f33a5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_smile.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_smile.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_neutral.gif")) == "4e8b7a51c7f60a2362a4f67fbbc937e7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_neutral.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_neutral.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_shifty.gif")) == "b485a5374343e8aa45fcd25e919b8aec")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_shifty.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_shifty.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_dance.gif")) == "b7e11d832f670c0409d23cafaa8ebd8e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_dance.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_dance.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_hand.gif")) == "fc90b256cb4d643acf1701a5655efb42")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_hand.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_hand.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_pray.gif")) == "195772090f39a559afde011d948cdfb2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_pray.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_pray.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_biggrin.gif")) == "f970a6591668c625e4b9dbd3b7a450d7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_biggrin.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_biggrin.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_exclaim.gif")) == "da86bbf377f97d06047aa781a582c52f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_exclaim.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_exclaim.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_clap.gif")) == "2c89896da3b4caf1ef92889ad0672b9e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_clap.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_clap.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_drool.gif")) == "b206469a2c4afdcba57d56fbd0871439")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_drool.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_drool.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_naughty.gif")) == "97977aebbdc02eb3bedb03dc302d089a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_naughty.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_naughty.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_razz.gif")) == "7aec68426aa06f01e2b1ac250e5aee62")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_razz.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_razz.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/theme")) == "ddd31cca32957645dae0cc766d2eebc2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/theme</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/theme (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_redface.gif")) == "d7e9d095432cbcf09375ffc782c30c23")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_redface.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_redface.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_arrow.gif")) == "394bffa679f650b7d2f22aa263cc06ba")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_arrow.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_arrow.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_frown.gif")) == "5a50535a06def9d01076772e5e9d235b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_frown.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_frown.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_cry.gif")) == "7605eca95aaeda46e641745ef6f0e0b0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_cry.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_cry.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_sick.gif")) == "d998a746f60e61d1ea67a18df5688c19")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_sick.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_sick.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_mrgreen.gif")) == "54e8505227edae1e583cf2f9554abc3a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_mrgreen.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_mrgreen.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_snooty.gif")) == "e108015689c8fd501c1463ece170b88c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_snooty.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_snooty.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_mad.gif")) == "e4355c00894da1bd78341a6b54d20b56")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_mad.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_mad.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/eusa_eh.gif")) == "ebabf045c8a5175713bd0df70f171337")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/eusa_eh.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/eusa_eh.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/smileys/icon_idea.gif")) == "aaebc9c048367118ba65e1da46bc3e08")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/smileys/icon_idea.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/smileys/icon_idea.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./themes/phpbb2/templates/style.css.tpl.php")) == "60a711e920ef22c2b6017a1feba72665")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./themes/phpbb2/templates/style.css.tpl.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./themes/phpbb2/templates/style.css.tpl.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./debug/console.php")) == "7441eea8fbbeb1f1a7aa32c00ea58b8e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./debug/console.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./debug/console.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./debug/info.php")) == "02b1c6e7dd2656953c4fe7ad058ffd42")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./debug/info.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./debug/info.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./debug/log.php")) == "57289647cf20fa144544af070d7a1fa9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./debug/log.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./debug/log.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./AUTHORS")) == "9f685cd7629840fe020328307ffa07b2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./AUTHORS</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./AUTHORS (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./version")) == "e112ca75f3056fb54ab5cfd4723b62f3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./version</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./version (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/privmsg.class.php")) == "a979de157b493a42710319c5b39c07b5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/privmsg.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/privmsg.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/clear.class.php")) == "cc8605de4a69a2e3daf7f4256d338e3d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/clear.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/clear.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/debug.class.php")) == "5ca77c67d11e95cb4dbd6919cc7c2556")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/debug.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/debug.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/connect.class.php")) == "00ae43568d5d6dd3e02047eed2dd016d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/connect.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/connect.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/deop.class.php")) == "b4beb549acb8092b65f2f7f44df68619")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/deop.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/deop.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/send.class.php")) == "92ad39e903374f1df08c3270180e38d3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/send.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/send.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/banlist.class.php")) == "dc207b6efdeb45b62834b13fe172e797")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/banlist.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/banlist.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/error.class.php")) == "a0f84704861f77a27f64b25c829c28cf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/error.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/error.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/getonlinenick.class.php")) == "d4ff9405b07fda0b2019d54c867ed5ed")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/getonlinenick.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/getonlinenick.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/leave.class.php")) == "10ec9aee14c97ad87b17fd8811bb1754")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/leave.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/leave.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/updatemynick.class.php")) == "81287bc7e4cca7df439a5d1925a2d288")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/updatemynick.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/updatemynick.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/join.class.php")) == "6e371f513a7d6bff6942e132881d4f27")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/join.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/join.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/ban.class.php")) == "50c8dfbf521ea804c47c41c3ef59cb27")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/ban.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/ban.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/getnewmsg.class.php")) == "72ec60c957e8c3dae0f550da5f93e4b3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/getnewmsg.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/getnewmsg.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/me.class.php")) == "b800292930fd6db362c801594d5a8c0b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/me.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/me.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/init.class.php")) == "b7ecdf1de678b9d81af827e9c78c2783")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/init.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/init.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/unban.class.php")) == "ea04127afdc2afed1695083e060ed724")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/unban.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/unban.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/privmsg2.class.php")) == "d2641f299adb8a6dd8d2e0e7e3cf51a7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/privmsg2.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/privmsg2.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/rehash.class.php")) == "49d990e2dd1770e11e40f6d22d4016cf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/rehash.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/rehash.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/identify.class.php")) == "08a326a23b817579d975340bbde3b9cd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/identify.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/identify.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/op.class.php")) == "4969543612f31925f4c50b82f9504ac3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/op.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/op.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/kick.class.php")) == "ba6cb332da60893403d82d21bbe6b9d5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/kick.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/kick.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/join2.class.php")) == "971365bb2c2146c5be0c777f61ac97e2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/join2.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/join2.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/notice.class.php")) == "1802da5876deb55757b70e33e1629714")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/notice.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/notice.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/quit.class.php")) == "3ed4013bb2a411b467d0e880a0e153f9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/quit.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/quit.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/update.class.php")) == "60ea49f54bfe721c4fdd908b574c8e14")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/update.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/update.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/asknick.class.php")) == "e33914d2dee88dc5dfea6efb38378f41")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/asknick.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/asknick.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/commands/nick.class.php")) == "5d3edf6c6ec6a0580015f99173d87bbe")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/commands/nick.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/commands/nick.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfctools.php")) == "997cf6ec1bb96c58314401179c5463f6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfctools.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfctools.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/phpfreechat.class.php")) == "7a4178efd4c233f6a0496eb2b97862d5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/phpfreechat.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/phpfreechat.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfccommand.class.php")) == "cc0c677ccaed91cd0ad67f874e689f33")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfccommand.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfccommand.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfci18n.class.php")) == "ffe6c42fd2fd079a26b22a87d41cd74e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfci18n.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfci18n.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/proxys/noflood.class.php")) == "a5c70f463d71914e4b635515eddf0b1c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/proxys/noflood.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/proxys/noflood.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/proxys/lock.class.php")) == "8d48ce043e0c28b5ffea617cdb6992c1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/proxys/lock.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/proxys/lock.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/proxys/censor.class.php")) == "a87bf97ac3279546066bfd53b71f7320")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/proxys/censor.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/proxys/censor.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/proxys/auth.class.php")) == "24984e493c9a9d5db9468aea8614ea3c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/proxys/auth.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/proxys/auth.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/containers/memory.class.php")) == "64868582154332b4bbfc70b3fbf0423d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/containers/memory.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/containers/memory.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/containers/file.class.php")) == "7337d22ba1f3531e9d21b2610aad234d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/containers/file.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/containers/file.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfcproxycommand.class.php")) == "9b1694408736c8f3fa33187eee64ce47")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfcproxycommand.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfcproxycommand.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfcglobalconfig.class.php")) == "dcf4bff36e6a51af5b878ad3e1338c1f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfcglobalconfig.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfcglobalconfig.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfccontainer.class.php")) == "a14fd6cbfa8a77d17632091f4d42d855")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfccontainer.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfccontainer.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfcuserconfig.class.php")) == "c57712e3cb67475923d783993d99cb7f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfcuserconfig.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfcuserconfig.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfctemplate.class.php")) == "403fd8bcd8ee81754a418a4186a464b5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfctemplate.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfctemplate.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./src/pfcinfo.class.php")) == "7de784a31d27c012c8a592b65b225927")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./src/pfcinfo.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./src/pfcinfo.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/version.class.php")) == "b4be41fce114654ffdf9098e499edbfe")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/version.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/version.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/themes.class.php")) == "7605d820749de92731c509cd6a899e9b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/themes.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/themes.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/logo_88x31.gif")) == "e6a73f260f19df15f50224edf9d1430e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/logo_88x31.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/logo_88x31.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/header.css")) == "3d13fad671f9ef243cdbf6b9e0a6964f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/header.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/header.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/valid-css.png")) == "875d489d9db31295538f9437b0650d0e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/valid-css.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/valid-css.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/content.css")) == "fdf439d6fb6805c2e0a4f8c360a747cb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/content.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/content.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/generic.css")) == "bde40b3db3ce695768205bad3cbde2c5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/generic.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/generic.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/footer.css")) == "d0c28acb83127a74c6c3799f92bf09dd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/footer.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/footer.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/bulle.png")) == "1306c813ef5bbad78d1ef6eb95dfd533")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/bulle.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/bulle.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/check_off.png")) == "b69db3cbc5d88fc8fa9be93a50cf1802")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/check_off.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/check_off.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/menu.css")) == "5611ea5f902618fc3a1d888324c1e53a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/menu.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/menu.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/show.js")) == "68fde759190b3d58950b452f2a2cd85c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/show.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/show.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/check_on.png")) == "643c611173f9fbb1993728791564de98")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/check_on.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/check_on.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/style/valid-xhtml.png")) == "47dacfb48738b9530b392e3410f7f484")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/style/valid-xhtml.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/style/valid-xhtml.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/inc.conf.php")) == "95e0f20b7730546548281952c94f05ce")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/inc.conf.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/inc.conf.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/user.php")) == "640d48ae9ad23806340a06e829750101")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/user.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/user.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/index_html_top.php")) == "6d98ef337436535d581482babb08bf8a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/index_html_top.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/index_html_top.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/themes.php")) == "b1ce1c0a1818b24d363eaff885017013")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/themes.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/themes.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/index_html_bottom.php")) == "fc243b3f4348e7e699789092db8b6aee")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/index_html_bottom.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/index_html_bottom.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/htaccess.class.php")) == "533fdb466738fbab478fc8a3ce529fd6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/htaccess.class.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/htaccess.class.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/index.php")) == "084ed6c0a7fc80bca254dace184c8c35")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/index.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/index.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./admin/configuration.php")) == "3c571530b2c27836839f5c62bb0e9ef0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./admin/configuration.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./admin/configuration.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./ChangeLog")) == "7c33fe86eb49779adcf0b3f07df47754")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./ChangeLog</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./ChangeLog (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/logo_88x31.gif")) == "e6a73f260f19df15f50224edf9d1430e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/logo_88x31.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/logo_88x31.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/checkmd5")) == "2f9d255578d06745d2afb5acbca2033f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/checkmd5</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/checkmd5 (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/clock-off.png")) == "16a6384b230479c258125da0eced5f4c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/clock-off.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/clock-off.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/bulle.png")) == "1306c813ef5bbad78d1ef6eb95dfd533")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/bulle.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/bulle.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/tabs.svg")) == "02dc973dc9cf45246f3cef1963cc84e2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/tabs.svg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/tabs.svg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/logo_80x15.png")) == "9e7b7baf87a0e2bad9c50634b2666c9b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/logo_80x15.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/logo_80x15.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/clock-on.png")) == "993a86ff21548368bd912da8c381ee9c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/clock-on.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/clock-on.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/login.png")) == "9982dea5d71d32f409117c06bc629c96")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/login.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/login.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/logout.png")) == "9e56228db0820eeaee172674d5a28330")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/logout.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/logout.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/logo_88x31.png")) == "e251122217fefdc10dce389fcf7e69bf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/logo_88x31.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/logo_88x31.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/logo.svg")) == "65ec511e2d42b0784dc7aadec1de28ab")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/logo.svg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/logo.svg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/png2gif.sh")) == "51c749d6e30da2150572587de04b0f9c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/png2gif.sh</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/png2gif.sh (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/login.svg")) == "c89ef14d3f40ec6b555f76722ab140c5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/login.svg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/login.svg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/logout.svg")) == "3083e2b038ff7fb87130dde8ccef3c9d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/logout.svg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/logout.svg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/i18n_update.php")) == "52c1e06f226c231e38cbeb209c0af8a4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/i18n_update.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/i18n_update.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/tarSource")) == "09d395ab4283d930541e25e6a8015c0d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/tarSource</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/tarSource (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/logo_80x15.gif")) == "a310104e2c7140b178973dba5bbab72f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/logo_80x15.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/logo_80x15.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/color-off.png")) == "e6c7a4168c9b9348417c49d21dc9aa63")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/color-off.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/color-off.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./misc/color-on.png")) == "5a15495292999a129ef760c8ace8b8b7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./misc/color-on.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./misc/color-on.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/misc/tarSource")) == "af0ff5cac920e0c2985713c6e4942a10")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/misc/tarSource</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/misc/tarSource (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/config.php")) == "bd358cbf70a13f7431a60ba048621e45")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/config.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/config.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/server_script.php")) == "3111e005a485fa21c563141b94806e1b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/server_script.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/server_script.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/tools.php")) == "cc37e7eb455b1ed96ab3d487fbaa860a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/tools.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/tools.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/index.php")) == "0999c8e36479784105b3e19f96b21794")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/index.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/index.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/icon.png")) == "57ae52a53c0f2b9375f9230c408b9a69")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/icon.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/icon.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/desc.xml")) == "02d3d1044179a4ac6e518e28cb621a9b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/desc.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/desc.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/dcChat/functions.php")) == "d5ffe34f4ec76fbc63cfb20bed174af6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/dcChat/functions.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/dcChat/functions.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller/installer_pages/2.txt")) == "564d9dba1e1cacbe570af53bdd94c3ff")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller/installer_pages/2.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller/installer_pages/2.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller/installer_pages/1.txt")) == "95605acce3e85f19f7ffb083a5788574")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller/installer_pages/1.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller/installer_pages/1.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller/page0.php")) == "2cb095211d157bc36acc5ad8c5ba810e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller/page0.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller/page0.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller/page1.php")) == "4dfc8188759d387b55ff8c42a516acd9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller/page1.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller/page1.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller/page2.php")) == "04ae84585cbfda58c2170696e39b015d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller/page2.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller/page2.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller/page3.php")) == "85d1456ac1d2977f517bf786dd9d9204")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller/page3.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller/page3.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller/page4.php")) == "9a0e396cf80e34630fa6057b6abdf00f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller/page4.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller/page4.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene.inc.php")) == "cbf852debbda984605a8ec09c6c2de69")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene.inc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene.inc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene_data/step_finished.txt")) == "96685f84124c659bb4fabb44a49341ec")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene_data/step_finished.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene_data/step_finished.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene_data/install.txt")) == "7d313b19fb577f3a923e179341c1e1db")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene_data/install.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene_data/install.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene_data/installer_data.txt")) == "25b9199c0a39cd696daf04eda20713cb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene_data/installer_data.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene_data/installer_data.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene_data/license.html")) == "4deb7cdde2251e550f7b72d45c22dd6f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene_data/license.html</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene_data/license.html (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene_data/step_path.txt")) == "b1d043f18e5b237404cd87553f37b37d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene_data/step_path.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene_data/step_path.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene_data/step_aboutto.txt")) == "28c9e699aa1342a98f49f55fb7b81113")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene_data/step_aboutto.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene_data/step_aboutto.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/engene_data/step_installer.txt")) == "c84e64825324c075255327ab90418117")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/engene_data/step_installer.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/engene_data/step_installer.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/createinstaller.php")) == "a1173ad30828121ec1df3ad384f14eec")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/createinstaller.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/createinstaller.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/genphpfromfile.php")) == "b2ea5c205d2d0ee71e35fa8447c641ce")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/genphpfromfile.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/genphpfromfile.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller/README")) == "ae850560c96f4f8c4ef039a79c06f2dd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller/README</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller/README (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/OS/Guess.php")) == "ee62a2e2e0fcc0a5cd27bee95ee58414")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/OS/Guess.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/OS/Guess.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/Archive/Tar.php")) == "5a9ef212cbfc1789c875870b3a4db6e5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/Archive/Tar.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/Archive/Tar.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.registry/console_getopt.reg")) == "b216c282f85774de4d1169b195fdb002")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.registry/console_getopt.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.registry/console_getopt.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.registry/archive_tar.reg")) == "510c1ed282c07631d53e09a980684dfe")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.registry/archive_tar.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.registry/archive_tar.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.registry/pear.reg")) == "2b0e431e32b320027b3501f3e2c1f242")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.registry/pear.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.registry/pear.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.registry/net_url.reg")) == "852714253b6d705c2c00c26dadbcbf48")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.registry/net_url.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.registry/net_url.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.registry/mime_type.reg")) == "ba34511f6aa9ccb08cdeedd7fef59f21")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.registry/mime_type.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.registry/mime_type.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.registry/php_compat.reg")) == "9e808e1f37fde7af155228e9626c415d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.registry/php_compat.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.registry/php_compat.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.registry/net_socket.reg")) == "5c3d8d99ce6cd4e9e41aba22cd0f6d52")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.registry/net_socket.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.registry/net_socket.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/Net/Socket.php")) == "1c7a9a28fc3fa78e682200d7540b66d5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/Net/Socket.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/Net/Socket.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/Net/URL.php")) == "d866df779667eefd7700ef3499ad7c33")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/Net/URL.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/Net/URL.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile.php")) == "598db4d68fe0a987d7e0f1cdf0e4d34c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Remote.php")) == "c704992361a23bd6376eba628e5c181b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Remote.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Remote.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/Generator/v1.php")) == "e7fb7a7d42513bf8d1cb22be2555c95f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/Generator/v1.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/Generator/v1.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/Generator/v2.php")) == "ccbc79878084a95934ce4151917b3569")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/Generator/v2.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/Generator/v2.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/v2/Validator.php")) == "cd4bcee5dd4185c1d50606a0f6dfdb67")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/v2/Validator.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/v2/Validator.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/v2/rw.php")) == "c58ef4160821046147ab07d1302b57bc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/v2/rw.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/v2/rw.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/Parser/v1.php")) == "00a3eeb81d152e2676a7991086a18107")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/Parser/v1.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/Parser/v1.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/Parser/v2.php")) == "dd9f79095782a8952f106398d160e9e9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/Parser/v2.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/Parser/v2.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/v1.php")) == "0768d80af0867b3d0546a39b49a9b33d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/v1.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/v1.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/PackageFile/v2.php")) == "4afeb8e676d8131cec043065e3c23705")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/PackageFile/v2.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/PackageFile/v2.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer.php")) == "e6e53bbd09ecba0b07509091a12c7e48")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Dependency2.php")) == "ff3caa3490e86cd12aae7d7e2dd6da9b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Dependency2.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Dependency2.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/RunTest.php")) == "e84410c2614ca4bd476999911fb2c6d6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/RunTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/RunTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Script.php")) == "67f4cf24289d4aa8d1acaa6418f23b55")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Script.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Script.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Src.xml")) == "67a2af8000b529b4c1e4a0d74136bf6f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Src.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Src.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Php.xml")) == "8bfb86cfb489b845f533b4932f29c085")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Php.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Php.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Ext.php")) == "8a08f270c45c2222186a5486f668d578")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Ext.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Ext.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Script.xml")) == "299e4a86f05e8675cb74010b1fd1c2c4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Script.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Script.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Doc.php")) == "09dd0319a8eef79c3ca57f4566fed199")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Doc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Doc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Ext.xml")) == "2bf6279186f754fb887588c640418582")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Ext.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Ext.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Data.php")) == "a3c72de21c69397def5728af14a78843")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Data.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Data.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Common.php")) == "d10ce4b20338ffd1edfc359febe0bdd4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Doc.xml")) == "d73975df77d911ff702626f56576c84e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Doc.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Doc.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Test.php")) == "269f1c6a8f80c8b394a61ec0c75cdadb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Test.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Test.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Data.xml")) == "dbf35f64689c3b66efb6b62fa94ea003")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Data.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Data.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Src.php")) == "83eb348b53742865cb2b407a8d46f65e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Src.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Src.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Php.php")) == "686007b2262e3c580fd63789321d4080")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Php.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Php.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role/Test.xml")) == "1ba14a3b49514618c574188fd9d02467")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role/Test.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role/Test.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Installer/Role.php")) == "76598c2f861abd8865b8e8709eabbe9f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Installer/Role.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Installer/Role.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Config.php")) == "8368510d5a230644029199c0ecfe5b5e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Config.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Config.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/ChannelFile.php")) == "e6712ddd25e19f35c38bed3288569017")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/ChannelFile.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/ChannelFile.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Registry.php")) == "dd0d6cd4d156d9c1cc08782dd0d52568")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Registry.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Registry.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/ChannelFile/Parser.php")) == "fa4fd2637ae1d1940c95b7cbe8492ff4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/ChannelFile/Parser.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/ChannelFile/Parser.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/XMLParser.php")) == "99a0903b4bc12c3c11d42ea367aa32db")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/XMLParser.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/XMLParser.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/REST.php")) == "4231a00a1155665a3dcf5800630b0c11")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/REST.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/REST.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Frontend.php")) == "e5a69329a4991065c2246095b5286d68")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Frontend.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Frontend.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/REST/10.php")) == "b02fe4a31567189b27ce71133031cc3f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/REST/10.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/REST/10.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/REST/11.php")) == "65098f89192de370ae497d410dcf65db")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/REST/11.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/REST/11.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Frontend/CLI.php")) == "226ad09a6b0b66b1f5fda750de7ad383")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Frontend/CLI.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Frontend/CLI.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Validate.php")) == "b5eed7efa63f353a5a4183d346135d89")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Validate.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Validate.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Validator/PECL.php")) == "85c19dc2593c066e6f6b6ac29e93d081")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Validator/PECL.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Validator/PECL.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Exception.php")) == "00bd6dd1ab61fcc1ad111252a73f076c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Exception.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Exception.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Downloader.php")) == "8fa2f65fb5be34e33350d5f8b19b69ce")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Downloader.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Downloader.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Autoloader.php")) == "9a43f0635b1b3d7c3694d1f90c0ccf39")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Autoloader.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Autoloader.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Downloader/Package.php")) == "7622d726ca99c3165cea2c0c9a8a28c5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Downloader/Package.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Downloader/Package.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Postinstallscript/rw.php")) == "b282370837e9085025d8e0283aafdd57")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Postinstallscript/rw.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Postinstallscript/rw.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Windowseol.php")) == "d6e02b11a428e10a3e8077786a35c8a8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Windowseol.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Windowseol.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Unixeol/rw.php")) == "692c95f48f96a5c498e9d8471378b86f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Unixeol/rw.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Unixeol/rw.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Replace.php")) == "b1cff115dfa029aa78b56c74f9e2052b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Replace.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Replace.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Windowseol/rw.php")) == "d854d86043a1ef510b4cd2f947a71793")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Windowseol/rw.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Windowseol/rw.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Replace/rw.php")) == "5ce4ca63a16ef8787de1d44570f166d5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Replace/rw.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Replace/rw.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Postinstallscript.php")) == "278806d2dbd339f8e1030a0c5e33f2e6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Postinstallscript.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Postinstallscript.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Unixeol.php")) == "a183d0bfe5e534d52781c2b48c08d08e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Unixeol.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Unixeol.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Task/Common.php")) == "da058db58be449c0bedfa1de3edeb9ef")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Task/Common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Task/Common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Dependency.php")) == "f763d6f55d1889691423f1b243e87f25")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Dependency.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Dependency.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Packager.php")) == "5c1cfed99cfb6f00873c535e2bc7cda9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Packager.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Packager.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command.php")) == "2ef0505718a51a73b9a241110071eedd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Package.php")) == "dd45c2443f7d255ae0123d2e3d31b860")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Package.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Package.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Channels.php")) == "c48487f4f4e07748dde5ca8f6852cb96")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Channels.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Channels.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Remote.php")) == "0f685f51ae54c8915a9157c2ee88473e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Remote.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Remote.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Build.php")) == "d1497b1313f5f08bcff2940f01740850")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Build.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Build.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Auth.php")) == "9b3b8d6c44eff2cab52006e1c51dd691")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Auth.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Auth.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Package.xml")) == "5ba8bcdbba65f5ea6f8e13f1eb916dc6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Package.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Package.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Channels.xml")) == "e307cce68c482e801adb2aa7e03c685a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Channels.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Channels.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Remote.xml")) == "dc040dfd41ade988c4da0bca964805d9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Remote.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Remote.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Config.php")) == "a094f918d9d7c057c6863cbc0764c7f4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Config.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Config.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Install.php")) == "717e263dfca39ef2b97c4fe6c13efc0f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Install.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Install.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Pickle.php")) == "5f8b6a8e4eaf8c205319b2f030527312")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Pickle.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Pickle.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Build.xml")) == "0dd1f4d03caa38ecc7ce90a18487cce2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Build.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Build.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Registry.php")) == "7ca2226e5401f36df436139a3c625e78")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Registry.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Registry.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Mirror.php")) == "c7f5a85bed19405715fa6a255c442bb4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Mirror.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Mirror.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Auth.xml")) == "9bb6c87199a66c83c168b244d65d3435")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Auth.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Auth.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Config.xml")) == "a798e0f60da8618caf73fd8ffc3997b5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Config.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Config.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Install.xml")) == "9f55a32092e0224b1f0181c9964c07fc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Install.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Install.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Test.php")) == "6d82bbb61a734641bae05baab1c93cc8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Test.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Test.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Pickle.xml")) == "4ef345a0deb52889b1f58145e3055814")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Pickle.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Pickle.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Registry.xml")) == "1d4f127d373b25a3bde92a47d829fbd0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Registry.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Registry.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Mirror.xml")) == "1ae2b0f3b0621e5cd2d4f5f44fb486ea")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Mirror.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Mirror.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Common.php")) == "dc7553bfc7d52d85afd807a14ac0f538")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Command/Test.xml")) == "d2b52b961e0e6418a52bcf9bb4345ba5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Command/Test.xml</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Command/Test.xml (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/ErrorStack.php")) == "58d3cd12879fb3d5f3fb2f1eb3700d12")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/ErrorStack.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/ErrorStack.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/DependencyDB.php")) == "ac7ba6698adcd96c64c1782c870299af")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/DependencyDB.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/DependencyDB.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Builder.php")) == "b8cc12da754c4edb28b56002fba72e65")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Builder.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Builder.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR/Common.php")) == "2bfdee69002033892395f5c7359023ea")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR/Common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR/Common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/MIME/Type/Parameter.php")) == "4ccb02a17ad3871e996c1abe116c96ea")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/MIME/Type/Parameter.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/MIME/Type/Parameter.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/MIME/Type.php")) == "fc4b7ea3d1ecaefa1c6ec01af761b3b8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/MIME/Type.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/MIME/Type.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/strripos.php")) == "56a986fa60a681488bc88fc9efef34c4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/strripos.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/strripos.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/is_a.php")) == "841a0381fb313eb15c875e6a9505a559")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/is_a.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/is_a.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/image_type_to_mime_type.php")) == "22996605069ad4156b4fca17793f284d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/image_type_to_mime_type.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/image_type_to_mime_type.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/ob_get_flush.php")) == "f2655ed2a80997794e58818c06fb8190")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_get_flush.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_get_flush.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect_uassoc.php")) == "ef99f105fc75ed6132984606404a9d97")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect_uassoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect_uassoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_search.php")) == "2aeee35f597e0f5d0c49a85ddf3f3437")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_search.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_search.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/ini_get_all.php")) == "e7d1f8d9c9b99a338211af084b436339")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/ini_get_all.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/ini_get_all.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/convert_uuencode.php")) == "94e6c48e91fcbf615b82c0e152003972")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/convert_uuencode.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/convert_uuencode.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/fprintf.php")) == "189e66f8075951206de5489958c3c15f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/fprintf.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/fprintf.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect_assoc.php")) == "75d8ea71454d975f3d6bb3ad2120a1df")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect_assoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect_assoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/vsprintf.php")) == "fc806274b140710c788255c364c9a764")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/vsprintf.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/vsprintf.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_product.php")) == "dc7e75f8ae58ff5a3c287b7e1abfd48c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_product.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_product.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/call_user_func_array.php")) == "7ca73e01d3140be4634d46a9041a1015")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/call_user_func_array.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/call_user_func_array.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/str_split.php")) == "355d5e7502132d172069dba5328272bc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/str_split.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/str_split.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/scandir.php")) == "465e20ea1af6ce534955eb8ffb201185")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/scandir.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/scandir.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/file_put_contents.php")) == "19480b314ef1f2bbff81966ea4626126")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/file_put_contents.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/file_put_contents.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/vprintf.php")) == "0f4321f32999f0e6ce8dfaf72773226f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/vprintf.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/vprintf.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/file_get_contents.php")) == "08e15713609fb3c28edd61f29b1494b5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/file_get_contents.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/file_get_contents.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/version_compare.php")) == "b6b782781db7022c4df0c5eb443ca0f1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/version_compare.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/version_compare.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/get_include_path.php")) == "fd77fc118496da8c908163cb3cf37736")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/get_include_path.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/get_include_path.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/inet_ntop.php")) == "14fdc60ad50d2119ec8e1e7c3fdbcb0d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/inet_ntop.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/inet_ntop.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/ob_get_clean.php")) == "853b534d6eb7424fa2399bce7be7d0a8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_get_clean.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_get_clean.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/ob_flush.php")) == "7e2277198f610313f79715faa3a79176")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_flush.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_flush.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/debug_print_backtrace.php")) == "138022391a8a6ba516a34deedfa27a8f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/debug_print_backtrace.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/debug_print_backtrace.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/restore_include_path.php")) == "7bb99a2e7db5060542b5db73fd580eaf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/restore_include_path.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/restore_include_path.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/ibase_timefmt.php")) == "b494491361dda3c1204e086dc2bdc8e3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/ibase_timefmt.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/ibase_timefmt.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/set_include_path.php")) == "676d2ab521daf0863c70d8d673acd81c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/set_include_path.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/set_include_path.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/str_word_count.php")) == "346aafdfa67a9905c381c9f8dae78bac")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/str_word_count.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/str_word_count.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/str_ireplace.php")) == "c1c85705bf5b85a3a58a0d7a5b3b6b73")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/str_ireplace.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/str_ireplace.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_key.php")) == "652100f87ce22ba5a57dd04e35208d3e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_key.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_key.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_uassoc.php")) == "0af7a23c5d834748007e97f82e1ed5bf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_uassoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_uassoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_walk_recursive.php")) == "7cb3b04733110cf9a0c29144031fff73")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_walk_recursive.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_walk_recursive.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/str_shuffle.php")) == "89a7cadd09f5a870d394ed673c99052c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/str_shuffle.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/str_shuffle.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/php_strip_whitespace.php")) == "2a215dbfb3d7ce59c1fcaefd11fb201b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/php_strip_whitespace.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/php_strip_whitespace.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/md5_file.php")) == "83bba8f1c7a25caa6fa9b6bfa98969a6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/md5_file.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/md5_file.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/strpbrk.php")) == "a4e32a260b98e4dd22f593c40a9e8adb")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/strpbrk.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/strpbrk.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/substr_compare.php")) == "7bab2f891b28254523c6457a49da81fd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/substr_compare.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/substr_compare.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/constant.php")) == "6a103d2798f29e51051fc3273770ed53")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/constant.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/constant.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff.php")) == "fd842b6d29f7edddfb7a1b6ea9801253")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/str_rot13.php")) == "4fa1567f6a211637bc573849c5a31fd6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/str_rot13.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/str_rot13.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/clone.php")) == "5aeb70010718356738f25a3c646534b1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/clone.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/clone.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/time_sleep_until.php")) == "047e98524026814c71294b022fed172b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/time_sleep_until.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/time_sleep_until.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/ob_clean.php")) == "79606394d490caf3fb98fa0b57a6b981")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_clean.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/ob_clean.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/html_entity_decode.php")) == "ae8d6a0b748626c72108e02bb76820ff")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/html_entity_decode.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/html_entity_decode.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_ukey.php")) == "dcf365be026af3cef7fc49c5ed473956")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_ukey.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_ukey.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/stripos.php")) == "520b716b06db543e2bc968699d8b40db")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/stripos.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/stripos.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_key.php")) == "c96bd50e94e6b7a420e331084d902c52")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_key.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_key.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_chunk.php")) == "1a86d2c84842165dfdad5745f0d4504b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_chunk.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_chunk.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff_uassoc.php")) == "e1ffe99d89f1d402ea942d91650e9e16")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff_uassoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff_uassoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/floatval.php")) == "4fc2555da9239545158b86cab0c64417")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/floatval.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/floatval.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/pg_escape_bytea.php")) == "d6e90906ab1d0c51c2b67ab6fc55c602")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/pg_escape_bytea.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/pg_escape_bytea.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/get_headers.php")) == "41fbcc977dfe050549da9e44d1ec2b6d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/get_headers.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/get_headers.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/bcpowmod.php")) == "7e4a534e63dd82cc59c7f1728967fde0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/bcpowmod.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/bcpowmod.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_uassoc.php")) == "acdfec74e2033a784040988e5a1b941c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_uassoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_uassoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/pg_unescape_bytea.php")) == "8956a03327e1240b1956e63751076e8d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/pg_unescape_bytea.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/pg_unescape_bytea.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/mime_content_type.php")) == "6b24f9b556243a49b8bcb9f5b5df5612")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/mime_content_type.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/mime_content_type.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff_assoc.php")) == "917d7d03cd807656ba4f60bb35832b3e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff_assoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_udiff_assoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_change_key_case.php")) == "02953d8f36ca8e1dcce99cb0bee16919")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_change_key_case.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_change_key_case.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/htmlspecialchars_decode.php")) == "36611f5469fd0ae696cecb550daf857c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/htmlspecialchars_decode.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/htmlspecialchars_decode.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/var_export.php")) == "83e8cfdcb3c47b25058376851adbad14")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/var_export.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/var_export.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/fputcsv.php")) == "349c9833125c4337b996a205da2e0ed3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/fputcsv.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/fputcsv.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_ukey.php")) == "a6c035ae1117375c05745f0096918c60")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_ukey.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_ukey.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/convert_uudecode.php")) == "3c425ec56b8182fb0b159f947e26671b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/convert_uudecode.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/convert_uudecode.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_assoc.php")) == "fcb170979f96d68bc3aa71c148ea2868")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_assoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_diff_assoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/inet_pton.php")) == "ce8eacee887236595ecd6e37b3f4fe70")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/inet_pton.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/inet_pton.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/mhash.php")) == "a5cc2b1d2b8b128599cb8e269c8d170d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/mhash.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/mhash.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/pg_affected_rows.php")) == "e6cd264c30806973253185918d92a468")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/pg_affected_rows.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/pg_affected_rows.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_combine.php")) == "25908f363df140154e3dbf8300e37305")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_combine.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_combine.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/bcinvert.php")) == "68d6ad6f881f7970df4f6aa5720ea572")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/bcinvert.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/bcinvert.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/http_build_query.php")) == "2b7f20ceaebdb3836beeae0e71354d26")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/http_build_query.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/http_build_query.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect.php")) == "318ef67354099afce29a1b81120fe1bf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_uintersect.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_key_exists.php")) == "480e2ddf2baff55eee50cb131ae3f8bd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_key_exists.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_key_exists.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/idate.php")) == "b72f462dd9798a12852672bb502af10e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/idate.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/idate.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_assoc.php")) == "9963181611d233b12e958760f020d7da")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_assoc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Function/array_intersect_assoc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/E_STRICT.php")) == "1388d061b346a37cc94ef32f8c8ed788")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/E_STRICT.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/E_STRICT.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/STD.php")) == "8b4375138a28d4776a6f174459162b51")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/STD.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/STD.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/DIRECTORY_SEPARATOR.php")) == "9f167d16c79c48f3a1ca918874d9038c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/DIRECTORY_SEPARATOR.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/DIRECTORY_SEPARATOR.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/PATH_SEPARATOR.php")) == "5e9e33bf0df024a6e1ca10fae4e56b04")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/PATH_SEPARATOR.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/PATH_SEPARATOR.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/UPLOAD_ERR.php")) == "7ccf7c512953df803695f11178036ea4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/UPLOAD_ERR.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/UPLOAD_ERR.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/FILE.php")) == "11475146cee8867df3772a89a487c84d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/FILE.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/FILE.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/T.php")) == "5b66b02f465aee9f7970fc1fd9876663")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/T.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/T.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Constant/PHP_EOL.php")) == "c6ab3c6691119fc754502c6230749288")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Constant/PHP_EOL.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Constant/PHP_EOL.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat/Components.php")) == "8d050846eb2dae34c1986968306b316b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat/Components.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat/Components.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PHP/Compat.php")) == "2200111e360fd144d4b77ca366f1f375")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PHP/Compat.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PHP/Compat.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/peclcmd.php")) == "ea71ff1ec841997c59219b52b47e81a1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/peclcmd.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/peclcmd.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.filemap")) == "9538648a0e6552afa5b915afc653f287")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.filemap</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.filemap (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.depdb")) == "0c6c84cf6b8703c25dad5b9b03c42b15")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.depdb</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.depdb (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/tmp/data/PEAR/template.spec")) == "49fa5832188ad0531a39c60b0e579a3a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/tmp/data/PEAR/template.spec</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/tmp/data/PEAR/template.spec (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/tmp/data/PEAR/package.dtd")) == "12a22b5ff8905016ea2168570aa4c20a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/tmp/data/PEAR/package.dtd</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/tmp/data/PEAR/package.dtd (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/bin/peardev")) == "6a99f3fac7dcc81918c40143415af3ca")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/bin/peardev</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/bin/peardev (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/bin/pecl")) == "b8603a3aeee0932ee077636f44d08d2c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/bin/pecl</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/bin/pecl (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/bin/pear")) == "f3fd200b1439174ad0b97c9ad5d7bf9d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/bin/pear</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/bin/pear (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/index.php")) == "eaf02d9ffb4206fa52ce786f9c9909de")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/index.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/index.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/pearcmd.php")) == "ca680d2a2fac01efacf033b42988c542")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/pearcmd.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/pearcmd.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/pear.sh")) == "c18d0b61320cc48124806b12e3b61146")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/pear.sh</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/pear.sh (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/Console/Getopt.php")) == "add0781a1cae0b3daf5e8521b8a954cc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/Console/Getopt.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/Console/Getopt.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.depdblock")) == "d41d8cd98f00b204e9800998ecf8427e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.depdblock</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.depdblock (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.lock")) == "d41d8cd98f00b204e9800998ecf8427e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.lock</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.lock (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.channels/.alias/pecl.txt")) == "349e9d3695d23be22c10aa53e6ea2d98")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.channels/.alias/pecl.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.channels/.alias/pecl.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.channels/.alias/pear.txt")) == "a1a245482b682db1c9475666dd2a9783")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.channels/.alias/pear.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.channels/.alias/pear.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.channels/pecl.php.net.reg")) == "9938ddf1c8b9641eb91e470144ef12f7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.channels/pecl.php.net.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.channels/pecl.php.net.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.channels/__uri.reg")) == "b672e1e6547f78e949b163b920295640")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.channels/__uri.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.channels/__uri.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/.channels/pear.php.net.reg")) == "398429ce21e3b2a757f89604a31178e1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/.channels/pear.php.net.reg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/.channels/pear.php.net.reg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/System.php")) == "aea7151645152a044a9d62c73f210401")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/System.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/System.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/pearrc")) == "99c690790a4ee6042e9f5e7834f42fab")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/pearrc</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/pearrc (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./contrib/pfcInstaller2/PEAR.php")) == "4cb570303ab165e84897709e9e6ca2d4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./contrib/pfcInstaller2/PEAR.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./contrib/pfcInstaller2/PEAR.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./index.php")) == "520ecadd7e35c013dee66e19587576c0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./index.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./index.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./README.en")) == "9470ae4ac3ef24abcbe5ddb8570b6299")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./README.en</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./README.en (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/logo_88x31.gif")) == "e6a73f260f19df15f50224edf9d1430e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/logo_88x31.gif</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/logo_88x31.gif (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/header.css")) == "3d13fad671f9ef243cdbf6b9e0a6964f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/header.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/header.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/valid-css.png")) == "875d489d9db31295538f9437b0650d0e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/valid-css.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/valid-css.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/content.css")) == "1a6e7314f0784ac3fa643489b172a167")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/content.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/content.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/generic.css")) == "bde40b3db3ce695768205bad3cbde2c5")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/generic.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/generic.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/footer.css")) == "d0c28acb83127a74c6c3799f92bf09dd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/footer.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/footer.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/bulle.png")) == "1306c813ef5bbad78d1ef6eb95dfd533")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/bulle.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/bulle.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/check_off.png")) == "b69db3cbc5d88fc8fa9be93a50cf1802")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/check_off.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/check_off.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/menu.css")) == "5611ea5f902618fc3a1d888324c1e53a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/menu.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/menu.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/show.js")) == "68fde759190b3d58950b452f2a2cd85c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/show.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/show.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/check_on.png")) == "643c611173f9fbb1993728791564de98")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/check_on.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/check_on.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./style/valid-xhtml.png")) == "47dacfb48738b9530b392e3410f7f484")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./style/valid-xhtml.png</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./style/valid-xhtml.png (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/css_parser.php")) == "02437e3e2d84f43c59b23b924a0c52cc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/css_parser.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/css_parser.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/lang.inc.php")) == "ce0e97d1f44b7656ea54f0c388254562")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/lang.inc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/lang.inc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/data.inc.php")) == "d0e8921752242b137968171917d6d426")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/data.inc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/data.inc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/functions.inc.php")) == "4453743dc0f507d20c8fc5825792564c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/functions.inc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/functions.inc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/COPYING")) == "eb723b61539feef013de476e68b5c50a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/COPYING</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/COPYING (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/template.tpl")) == "033ec8431bd13449f4e309b5398f0280")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/template.tpl</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/template.tpl (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/css_optimiser.php")) == "edb4ccd6b23fd755b7822b3173a689c9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/css_optimiser.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/css_optimiser.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/template1.tpl")) == "9dc90ea5b4a33e0ced04bce67a0f2596")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/template1.tpl</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/template1.tpl (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/cssparse.css")) == "4ceff0c495507e71edac66ccc23331cd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/cssparse.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/cssparse.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/testing/css_results.php")) == "6da84b6bd261779b8c6cad009450d106")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/testing/css_results.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/testing/css_results.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/testing/base.css")) == "3120bb9581c306a92aa354ba38da6337")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/testing/base.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/testing/base.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/testing/fisubsilver.css")) == "cb2d94fabc5299293550dc04366f0f25")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/testing/fisubsilver.css</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/testing/fisubsilver.css (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/testing/auto-testing.php")) == "0a2fc14c87656421b9f02722effc245c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/testing/auto-testing.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/testing/auto-testing.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/template2.tpl")) == "85583463be705bba41de4ca685e0b98a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/template2.tpl</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/template2.tpl (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/template3.tpl")) == "eca04751270d01f79d25cb18838e6018")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/template3.tpl</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/template3.tpl (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/csstidy-1.1/README")) == "3a3e2ddf61de1689e042291b821262b0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/csstidy-1.1/README</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/csstidy-1.1/README (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/javascript/cookie.js")) == "1a4f8571119a724915eff57425424f7c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/javascript/cookie.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/javascript/cookie.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/javascript/md5.js")) == "ee3a962f93b0031161f08e7c6503f961")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/javascript/md5.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/javascript/md5.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/javascript/utf8.js")) == "231234f094dab73b1136f77e333290ca")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/javascript/utf8.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/javascript/utf8.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/javascript/regex.js")) == "d58fd695b962fb7e55a2337932ed649e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/javascript/regex.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/javascript/regex.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/javascript/image_preloader.js")) == "17c2707db87834cc753a107674de859b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/javascript/image_preloader.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/javascript/image_preloader.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/javascript/myprototype.js")) == "55c6c631ca3d2605589f693b83aa2922")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/javascript/myprototype.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/javascript/myprototype.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/utf8/utf8.php")) == "82ee17a9b8c2eac4bc6f55197becb03c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/utf8/utf8.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/utf8/utf8.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Eaccelerator.php")) == "5a9cbaa57e7a37be6f34622e26e97b61")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Eaccelerator.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Eaccelerator.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Systemv.php")) == "a87137b3a111b141628a9e2594d47f53")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Systemv.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Systemv.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Mmcache.php")) == "0b7335cd5b1f8a242e3bbf910d11fa5a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Mmcache.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Mmcache.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Sharedance.php")) == "e13c8308cedeb32549daf59b6435189c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Sharedance.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Sharedance.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/File.php")) == "8b51a4c3bb84aad42d95b5d14e91c2dd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/File.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/File.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Sqlite.php")) == "426ca8ca73a1da842061a8c8dc762bef")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Sqlite.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Sqlite.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Memcache.php")) == "751c35ca5c9228dbfd22d676c1471e34")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Memcache.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Memcache.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Apc.php")) == "3d5eb906896c8f413531b415559304cd")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Apc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Apc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Shmop.php")) == "40789f58dccfa36ff423fa482dfaf109")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Shmop.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Shmop.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Apachenote.php")) == "c26fdd50ed560080db0810396f3d1ab6")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Apachenote.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Apachenote.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/PEAR.php")) == "fd34f4b460945609926630731b2db9e3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/PEAR.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/PEAR.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory/Common.php")) == "cdd7b927edc31d5c1651dd4d90b156e7")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory/Common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory/Common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/System/SharedMemory.php")) == "bc655b24ef33a4f01bae58e68c6e0706")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/System/SharedMemory.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/System/SharedMemory.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/pear.sh")) == "c18d0b61320cc48124806b12e3b61146")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/pear.sh</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/pear.sh (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/GUI/HTML.tpl")) == "222a8fef6537f8fb1653f68f1b1d6a28")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/GUI/HTML.tpl</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/GUI/HTML.tpl (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/GUI/HTML.php")) == "6b48059f47b545903725bda0076cab4a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/GUI/HTML.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/GUI/HTML.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/GUI/Gtk.php")) == "2ca785505f2508f059993d9203edd166")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/GUI/Gtk.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/GUI/Gtk.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/GUI/SetupDecorator.php")) == "39a29415cdb5191f57529b70e1ca65d8")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/GUI/SetupDecorator.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/GUI/SetupDecorator.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/RepeatedTest.php")) == "ee280b97a8b06d6292767244a910e56c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/RepeatedTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/RepeatedTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/TestSuite.php")) == "13df054bceb10f7604a5796cac4361bc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/TestSuite.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/TestSuite.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/TestCase.php")) == "9b1d78d9ad5c9f6aa0fc3ae6bf180b20")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/TestCase.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/TestCase.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/TestDecorator.php")) == "a0be8efea0c4416fe8e2b3099253a0d9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/TestDecorator.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/TestDecorator.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/TestResult.php")) == "a0c025e0ca5f1922d781db6ccb29f2b9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/TestResult.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/TestResult.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/Assert.php")) == "02f09cb0b94b8450edfbd2536e02e39c")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/Assert.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/Assert.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/TestListener.php")) == "3ed518d5db2870b98198981b0b508e13")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/TestListener.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/TestListener.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/Skeleton.php")) == "1d9b6092a307cebc59a4633260475c06")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/Skeleton.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/Skeleton.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit/TestFailure.php")) == "8331637fa097f2d518b4fbd918e3e7b9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit/TestFailure.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit/TestFailure.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/PHPUnit.php")) == "333af11bab6eb201a1c941cded5bc9ed")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/PHPUnit.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/PHPUnit.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/pear/pearrc")) == "29c4f3f77a779177c7f6337b1112acf2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/pear/pearrc</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/pear/pearrc (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/customResponseClassTest.php")) == "9e8be79c2fcd7503fd4e1b4684cf2111")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/customResponseClassTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/customResponseClassTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/xajaxResponseTest.php")) == "a88398fe6ac53e650d4703dfd2d2b609")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/xajaxResponseTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/xajaxResponseTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/preFunctionTest.php")) == "06bf58072accc9a4373888562962f5d2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/preFunctionTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/preFunctionTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/errorHandlingTest.php")) == "45841c69edd20acf56cc42ef44672c36")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/errorHandlingTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/errorHandlingTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/registerExternalFunctionTest.php")) == "6b16b823fecba41213be8d40a84828a2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/registerExternalFunctionTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/registerExternalFunctionTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/myExternalFunction.php")) == "11a65ecd5e9932c00b65aa56263983fe")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/myExternalFunction.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/myExternalFunction.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/searchReplaceTest.php")) == "f8f31d888c9d0762be98fda3035d5404")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/searchReplaceTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/searchReplaceTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/redirectTest.php")) == "70fb4d60e8c50c2ac89bc363427ecc54")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/redirectTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/redirectTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/phpWhitespaceTest.php")) == "8233a36179a45bf0405ee5c23b3fa095")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/phpWhitespaceTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/phpWhitespaceTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/createFormInputTest.php")) == "d7b3db3778f47e4d639ea31b99910df1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/createFormInputTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/createFormInputTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/index.php")) == "5fc4ae316003064cf5926b2fefd52a89")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/index.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/index.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/largeResponseTest.php")) == "467d137e71690e129fdbc365e8a7e299")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/largeResponseTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/largeResponseTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/registerObjectTest.php")) == "c92424bfa9a49832cccc7ee31da6bb4b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/registerObjectTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/registerObjectTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/eventHandlerTest.php")) == "465c56296d88dd4d4c263ab22b7337e9")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/eventHandlerTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/eventHandlerTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/includeExternalScriptTest.php")) == "894adb9f1416f1999b70003af865d8f0")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/includeExternalScriptTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/includeExternalScriptTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/formSubmissionTest.php")) == "da929d9f40ae60f04084a030430dff11")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/formSubmissionTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/formSubmissionTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/disabledFormElementsTest.php")) == "bf60b96bf78c49a5c9b50ea4cf315f85")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/disabledFormElementsTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/disabledFormElementsTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/catchAllFunctionTest.php")) == "c62c0bed7e3d9f8403f440231f3bae6b")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/catchAllFunctionTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/catchAllFunctionTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/myExternalFunction.js")) == "31a9d5fe301382115c5e5fed005089d2")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/myExternalFunction.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/myExternalFunction.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/HTTPStatusTest.php")) == "522ec4ea1dea71c430a8de1592a509d4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/HTTPStatusTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/HTTPStatusTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/charEncodingTest.php")) == "6e6185a3d7b65e9257e5c13b4f1372ce")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/charEncodingTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/charEncodingTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/tests/changeEventTest.php")) == "e1eb1d291c809827e6cca27b6dc12985")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/tests/changeEventTest.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/tests/changeEventTest.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/LICENSE.txt")) == "80d5280342ccaa1edf2a4b1c87a47d94")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/LICENSE.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/LICENSE.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/xajax_js/xajax.js")) == "b2466e573f13700bdae53fc8479dec88")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/xajax_js/xajax.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/xajax_js/xajax.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/xajax_js/xajax_uncompressed.js")) == "993ad5d199b0f1bfaab49bd065a26baf")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/xajax_js/xajax_uncompressed.js</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/xajax_js/xajax_uncompressed.js (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/multiply/multiply.php")) == "a410222a41a638db79f78cb07e0ff1f4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/multiply/multiply.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/multiply/multiply.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/multiply/multiply.server.php")) == "ab5514dd7916aff20e705c2534b967b4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/multiply/multiply.server.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/multiply/multiply.server.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/multiply/multiply.common.php")) == "87a10ea37e4bf546837e4e6985ff2632")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/multiply/multiply.common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/multiply/multiply.common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/thewall/thewall.php")) == "6db3d5305cf59145d01f40fec98beb94")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/thewall/thewall.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/thewall/thewall.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/thewall/brick.jpg")) == "113df3c3b797b22ffd682c9fc2357c81")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/thewall/brick.jpg</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/thewall/brick.jpg (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/thewall/thewall.server.php")) == "f9992e798ccab95bd4b15d537069fbf1")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/thewall/thewall.server.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/thewall/thewall.server.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/thewall/thewall.common.php")) == "9be5a5abbbf2f1bf300e277ca63ae63d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/thewall/thewall.common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/thewall/thewall.common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/signup/signup.server.php")) == "d5ed71986e76035b860a58054d0fec1d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/signup/signup.server.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/signup/signup.server.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/signup/signup.common.php")) == "51efcfdbea7eb0f36566a736a953938e")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/signup/signup.common.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/signup/signup.common.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/signup/signup.php")) == "a8fba3e7efd0430aa214da4df7ce3a5a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/signup/signup.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/signup/signup.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/xul/xulApplication.php")) == "98ad031e3b3ec35579d8157be0e0de98")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/xul/xulApplication.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/xul/xulApplication.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/xul/xulServer.php")) == "867ed2ae3c354df45200aab8b53aa4fc")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/xul/xulServer.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/xul/xulServer.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/xul/xulClient.xul")) == "9d14b5d109d42842a378933b13a09d7d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/xul/xulClient.xul</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/xul/xulClient.xul (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/examples/helloworld.php")) == "869cd7e35152b27132e6c4fde6798c6f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/examples/helloworld.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/examples/helloworld.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/xajaxResponse.inc.php")) == "f1ea4c89a8f1b7e4c827bb9ed3fdd639")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/xajaxResponse.inc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/xajaxResponse.inc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/xajax.inc.php")) == "9c1afe3001141df5bbb24fa9945061c3")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/xajax.inc.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/xajax.inc.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/README.txt")) == "99a0e432b38b207467f9f6cb81120ced")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/README.txt</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/README.txt (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./lib/xajax_0.2.3/xajaxCompress.php")) == "e42e4cfc84480a64056b897362eef906")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./lib/xajax_0.2.3/xajaxCompress.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./lib/xajax_0.2.3/xajaxCompress.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./data/private/.htaccess")) == "55e3fab406c794358a55ecd986e4c3ef")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./data/private/.htaccess</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./data/private/.htaccess (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./README.fr")) == "ed81ad51d85337d4a1f6698b23a2eced")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./README.fr</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./README.fr (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./testcase/container_file.php")) == "31a11a38b487fafde3ad991eadc5dc99")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./testcase/container_file.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./testcase/container_file.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./testcase/cmd_error.php")) == "77c609c6dd91a68a13ad4af8956e424d")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./testcase/cmd_error.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./testcase/cmd_error.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./testcase/cmd_send.php")) == "a66c939ad740ea56e28226a53bfd7128")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./testcase/cmd_send.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./testcase/cmd_send.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./testcase/container_generic.php")) == "0d31d31344fccd5df677b406963b4e74")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./testcase/container_generic.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./testcase/container_generic.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./testcase/cmd_nick.php")) == "c11997fb05596f22f987ff6070f7b41a")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./testcase/cmd_nick.php</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./testcase/cmd_nick.php (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./INSTALL.en")) == "e7feaa3b3bab21d0cdbdf6d5db9139d4")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./INSTALL.en</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./INSTALL.en (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./COPYING")) == "6316f2b9af0cab4497de71b53e26a01f")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./COPYING</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./COPYING (please replace this file by a correct one)</span>\n";
if (md5(file_get_contents("./INSTALL.fr")) == "aac1cd93e3f5c0d393163783411b5804")
  $files_ok[] = "<span style=\"color:#3A3\">ok - ./INSTALL.fr</span>\n";
else
  $files_ko[] = "<span style=\"color:#F33\">corrupted - ./INSTALL.fr (please replace this file by a correct one)</span>\n";
echo "<h2>Checking phpfreechat files validity</h2>";
echo "<pre>\n";
$arr = array_merge($files_ko,$files_ok);
foreach($arr as $file)
  echo $file;
echo "</pre>\n";
?>
